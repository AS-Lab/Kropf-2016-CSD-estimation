%% General Parameters
% Should info about the processing be displayed
TextOutput = true; % either true or false

% Should simulated data be used. If set to false, data needs to be provided
UseSimData = true; % either true or false

% Calculate Optimal Estimate (i.e. estimation of CSD minimizing the error 
% to the depth profile used to simulate the data) 
% (only works with simulated data object)
CalcOpt = true; % either true or false

% Calculate Ideal Estimate (i.e. estimation CSD without noise)
% (only works with simulated data object)
CalcIdeal = true; % either true or false

% Calculate Estimation Error (only works with simulated data object)
CalcErr = true; % either true or false

% Should the plot related to the resolution be computed and shown?
PlotRes = true; % true or false

FontSize = 10; % Font sizes for the plots

%% Define Inverse Parameters
% Define the Electrode Positions 
% surface is at z == 0 for 2 layered medium
% for 3-layered medium, boundary between top and medium medium is at z = 0
ChanSep = 0.1; % in mm
BrainBound = 5; % First channel in the brain
offset = 0.05; % in mm, offset of the first channel from the surface
NumChan = 32; % Number of channels on the electrode
ElectrodePositions  = -(BrainBound-1)*ChanSep+offset:ChanSep:(NumChan-BrainBound)*ChanSep +offset; % in mm

% Set Bad Channels
InvPara.BadChannels = [];

% Should the potential be interpolated across BadChannels. For no leave
% it empty. Otherwise a valid string for interp1 has to be used
InvPara.InterpPot = []; % 'nearest', 'linear', 'spline', 'pchip'

% Define the positions where the CSD should be estimated
% ReadOutRegion = -0.6:0.01:3; 
ReadOutRegion = ElectrodePositions(1)-ChanSep:0.01:ElectrodePositions(end)+ChanSep;% in mm

% Select number of layers in inverse model 
% 1 = homogeneous volume conductor [only uses MidCond]
% 2 = 2-layers [uses TopCond for z < 0 and MidCond for z >= 0]
% 3 = 3-layers [uses TopCond for z < 0, MidCond for 0 <= z <=
% WhiteMatterDepth and BottomCond for z > WhiteMatterDepth]
InvPara.NumLayers = 2;

% Define Conductivity of media
InvPara.ExCond = 0.3; % in S/m
InvPara.TopCond = 1.7; %in S/m
InvPara.BottomCond = 0.1; %in S/m

InvPara.WhiteMatterDepth = 2; % in mm

% Define the assumed source shape
% 'UniCyl' = Uniform Cylinder
% 'Gaussian' = Gaussian lateral profile
InvPara.SourceShape = 'UniCyl'; % either 'UniCyl' or 'Gaussian'

% Define the assumed source diameter
InvPara.Diameter = 1; % in mm

%% Create Simulated Potential Object

if UseSimData
    Params.SourceShape = 'UniCyl';  %either 'UniCyl', 'Gaussian' or 'InfPlane'
    Params.NumLayers = 2; % either 1,2, or 3
    Params.ExCond = 0.3; % in S/m
    Params.TopCond = 1.7;% %in S/m
    Params.BottomCond = 0.1;% %in S/m
    Params.Diameter = 1; % in mm
    Params.Jitter = 0; % -1;%in mm
    Params.NoiseType = 'normal'; %'uniform', 'normal'
    Params.NoiseAmp = 0.01; % in mV
    Params.SNRdB = []; % in dB
    % Params.SNRlin = 10;
    
    Params.NumSamples = 1;
    Params.NumTrials = 50;
    Params.SourceInt = 1;
    
    % Source depth profile (either 'sine', 'gauss','glabska', 'mono', 'dipole',
    %'quad' or insert a z-dependent function handle)
    Params.SourceFunc = 'gauss';
    switch Params.SourceFunc
        case 'sine'
            Params.zstart = 0.1;
            Params.lambda = 1;
            Params.zend = 2.1;
        case 'gauss'
            Params.mu1 = 0.3;
            Params.sigma1 = 0.08;
            Params.mu2 = 0.8;
            Params.sigma2 = 0.23;
        case 'mono'
            Params.amp1 = -1;
            Params.mu1 = 0.3;
            Params.sigma1 = 0.08;
        case 'dipole'
            Params.amp1 = 1;
            Params.mu1 = 0.3;
            Params.sigma1 = 0.08;
            Params.amp2 = 1;
            Params.mu2 = 0.6;
            Params.sigma2 = 0.08;
        case 'quad'
            Params.amp1 = 0.5;
            Params.mu1 = 0.3;
            Params.sigma1 = 0.08;
            Params.amp2 = 1;
            Params.mu2 = 0.6;
            Params.sigma2 = 0.08;
            Params.amp3 = 0.5;
            Params.mu3 = 0.9;
            Params.sigma3 = 0.08;
    end
    
    SimObj = SimPot2layer(ElectrodePositions, TextOutput, Params);
end

%% Create estimation object

% Which source parameterization method should be used
EstMethod = 'iCSD'; % either 'rCSD', 'iCSD', 'kCSD', 'eCSD' or 'qCSD'

switch EstMethod
    case 'iCSD'
        BasisShape = 'Spline'; % 'Delta', 'Step', 'StepA', 'StepB' or 'Spline'

        % Create the inverse object
        C = iCSDclass(ElectrodePositions, InvPara, TextOutput, BasisShape);
    
    case 'kCSD'
        SourceRegionBounds = [ElectrodePositions(1)-ChanSep ElectrodePositions(end)+ChanSep]; %  in mm

        BasisShape = 'Gaussian'; % 'Gaussian' or 'Step'

        NumSrc = 67; 

        w = 0.15;

        % Create the inverse object
        C = eCSDclass(ElectrodePositions, InvPara, TextOutput, SourceRegionBounds, BasisShape, NumSrc, w);

    case 'eCSD'
        SourceRegionBounds = [ElectrodePositions(1)-ChanSep ElectrodePositions(end)+ChanSep]; %  in mm

        BasisShape = 'Gaussian'; % 'Gaussian' or 'Step'

        NumSrc = 67; 

        w = 0.15;

        % Create the inverse object
        C = kCSDclass(ElectrodePositions, InvPara, TextOutput, SourceRegionBounds, BasisShape, NumSrc, w);

    case 'rCSD'
        
        SourceRegionBounds = [ElectrodePositions(1)-ChanSep ElectrodePositions(end)+ChanSep]; %  in mm

        % Create the continuous inverse object
        C = rCSDclass(ElectrodePositions, InvPara, TextOutput, SourceRegionBounds);

    case 'qCSD'
        QuadMethod = 'Simpson'; % either 'MidPoint', 'Trap', 'Simpson'
%         QuadPoints = ReadOutRegion; % in mm either QuadPoints or [Bound1 Bound2 NumPoints]
        % QuadPoints = [-1 3 51];
        QuadPoints = ReadOutRegion(ReadOutRegion >= ElectrodePositions(1)-ChanSep & ReadOutRegion <= ElectrodePositions(end)+ChanSep); % in mm either QuadPoints or [Bound1 Bound2 NumPoints] 
        QuadPoints = QuadPoints(1:5:end);
        % Create the quadrature inverse object
        C = qCSDclass(ElectrodePositions, InvPara, TextOutput, QuadMethod, QuadPoints);

end



%% Estimate rCSD F matrix

C.CalcFmat;

%% Set Potential

if UseSimData
    C.SimPotObj = SimObj;
else
    % To use with real data for proper handling of the bad channels
    C.SetPotential(Pot); % Pot should be in mV for proper units
end

%% Estimate Weigths
Prior =[0 1 2];% either [], 0, 1, 2, [0 1], [0 2], or [0 1 2]
RegParam.Prior = Prior;
RegParam.PriorType = 'Coeff'; % either 'Coeff', 'Model'
RegParam.RegMethod = 'tikhonov'; % either 'tikhonov','dsvd','tsvd'
RegParam.LambdaMethod = 'ncp'; % either 'l_curve','gcv','quasi','ncp', or 'user_specified'
RegParam.RegLambda = 0;%[]; % only used for 'user_specified' LambdaMethod
RegParam.EtaBound = []; % only applicable to 'l_curve'
RegParam.ExtraReg = false; % Extra Regularization (does not work on [] prior)
RegParam.ExtraRegRegions = [C.SourceRegionBounds(1) 0 10;...% [bound1(1) bound1(2) weight1;  bound2(1) bound2(2) weight2]
                            2 C.SourceRegionBounds(2) 10]; 
RegParam.TrialWise = true;

C.EstimateWeightsHansen(RegParam);

if CalcOpt
    % Optimal possible estimation of the CSD (optional)
    C.FindOptimalLambdaHansen; % Only for simulated data object
end

%% Generate CSD ReadOut

% Estimated CSD
C.GenCSDest(ReadOutRegion);
CSDnorm = sum(C.ReadOutSampling*C.CSDest.^2);
if CalcErr && UseSimData
    C.CalculateEstErr; % Only for simulated data
    
    RealCSDnorm = sum(C.ReadOutSampling*C.SimPotObj.RealCSD(C.ReadOutRegion).^2);
    SSE = sqrt(sum(C.ReadOutSampling*C.EstErr.^2,1))/sqrt(RealCSDnorm);
end

if CalcOpt && UseSimData
    % Estimation of CSD minimizing the error to the depth profile used to
    % simulate the data
    C.GenOptimalCSDest(ReadOutRegion);
    OptCSDnorm = sum(C.ReadOutSampling*C.OptimalCSDest.^2);
    C.GetOutliers;
    if CalcErr
        C.CalculateOptimalEstErr;
        SSEopt = sqrt(sum(C.ReadOutSampling*C.OptimalEstErr.^2,1))/sqrt(RealCSDnorm);
    end
end

if CalcIdeal && UseSimData
    % Estimation of CSD without noise
    C.GenIdealCSDest(ReadOutRegion);
    IdealCSDnorm = sum(C.ReadOutSampling*C.IdealCSDest.^2);
    
    if CalcErr
        C.CalculateIdealEstErr;
        SSEideal = sqrt(sum(C.ReadOutSampling*C.IdealEstErr.^2,1))/sqrt(RealCSDnorm);
    end
end
   
%% Make legend string for plotting
legstr = {'True CSD', 'Ideal Est.', 'Optimal \lambda', EstMethod};
idx = nan(length(legstr),1);
count = 1;
if UseSimData
    idx(count) = 1;
    count = count+1;
    if CalcIdeal
        idx(count) = 2;
        count = count+1;
    end
    if CalcOpt
        idx(count) = 3;
        count = count+1;
    end
end
idx(count) = 4;
idx(isnan(idx)) = [];

%% Plot Results
hF1 = figure;
subplot(1,2,1)
hold on;
if UseSimData
    plot(C.SimPotObj.NoiseFreePot(:,:,1), C.SimPotObj.ElectrodePositions+C.SimPotObj.RealJitter,'LineWidth', 3, 'color', 'k')
end
plot(C.Pot(:,:,1), C.ElectrodePositions,'LineWidth', 2, 'color', 'r')
if ~isempty(C.BadChannels)
    plot(C.Pot(C.BadChannels), C.ElectrodePositions(C.BadChannels)','Marker', 'o', 'MarkerSize', 7, 'MarkerEdgeColor', 'r','MarkerFaceColor', 'b', 'Linestyle', 'none');
end
hold off
if UseSimData
    legend('Real Potential', 'Assumed Potential','Location', 'SouthEast')
end
xlabel('Potential (mV)'); ylabel('Position (mm)');
ylim([ReadOutRegion(1) ReadOutRegion(end)]);
title('Pot Trial 1')
addline([0 0],'vh','LineStyle', ':', 'LineWidth', 1, 'color', 'g');
axis('ij')

subplot(1,2,2)
hold on;
if UseSimData
    plot(C.SimPotObj.RealCSD(C.ReadOutRegion), ReadOutRegion,'LineWidth', 3, 'color', 'k')
    if CalcIdeal
        plot(mean(C.IdealCSDest(:,:,~C.RegOutlier),3),C.ReadOutRegion,'LineWidth', 2,'color', 'b');
    end
    if CalcOpt
        plot(mean(C.OptimalCSDest(:,:,~C.RegOutlier),3),C.ReadOutRegion,'LineWidth', 2,'color', 'r');
    end
end
plot(mean(C.CSDest(:,:,~C.RegOutlier),3),C.ReadOutRegion,'LineWidth', 2,'color', 'm');
hold off
if UseSimData
    xlim([-1.5*mean(abs(C.SimPotObj.SourceInt),2) 1.5*mean(abs(C.SimPotObj.SourceInt),2)])
end
ylim([ReadOutRegion(1) ReadOutRegion(end)])
addline([0 0],'vh','LineStyle', ':', 'LineWidth', 1, 'color', 'g');
xlabel('Source Density (\muA/mm^3)'); ylabel('Position (mm)');
legend(legstr(idx), 'Location', 'SouthEast');
title('Trial Averaged CSD Est.')
axis('ij')
set(findall(hF1,'-property','FontSize'),'FontSize',FontSize)


%% Plot Single trial
Trial = size(C.Pot,3);
if C.NumTrials >= Trial
    hF2 = figure;
    subplot(1,2,1)
    hold on;
    if UseSimData
        plot(C.SimPotObj.NoiseFreePot(:,:,Trial), C.SimPotObj.ElectrodePositions+C.SimPotObj.RealJitter,'LineWidth', 3, 'color', 'k')
    end
    plot(C.Pot(:,:,Trial), C.ElectrodePositions,'LineWidth', 2, 'color', 'r')
    if ~isempty(C.BadChannels)
        plot(C.Pot(C.BadChannels), C.ElectrodePositions(C.BadChannels)','Marker', 'o', 'MarkerSize', 7, 'MarkerEdgeColor', 'r','MarkerFaceColor', 'b', 'Linestyle', 'none');
    end
    hold off
    legend('Real Potential', 'Assumed Potential')
    xlabel('Potential (mV)'); ylabel('Position (mm)');
    ylim([ReadOutRegion(1) ReadOutRegion(end)])
    title(['Pot Trial ' num2str(Trial)])
    addline([0 0],'vh','LineStyle', ':', 'LineWidth', 1, 'color', 'g');
    axis('ij')
    
    subplot(1,2,2)
    hold on;
    if UseSimData
        plot(C.SimPotObj.RealCSD(C.ReadOutRegion), ReadOutRegion,'LineWidth', 3, 'color', 'k')
        if CalcIdeal
            plot(squeeze(C.IdealCSDest(:,1,Trial)),C.ReadOutRegion,'LineWidth', 2,'color', 'b');
        end
        if CalcOpt
            plot(squeeze(C.OptimalCSDest(:,1,Trial)),C.ReadOutRegion,'LineWidth', 2,'color', 'r');
        end
    end
    plot(squeeze(C.CSDest(:,1,Trial)),C.ReadOutRegion,'LineWidth', 2,'color', 'm');
    hold off
    if UseSimData
        xlim([-1.5*mean(abs(C.SimPotObj.SourceInt),2) 1.5*mean(abs(C.SimPotObj.SourceInt),2)])
    end
    ylim([ReadOutRegion(1) ReadOutRegion(end)])
    addline([0 0],'vh','LineStyle', ':', 'LineWidth', 1, 'color', 'g');
    title(['CSD Est. Trial ' int2str(Trial)]);
    xlabel('Source Density (\muA/mm^3)'); ylabel('Position (mm)');
    legend(legstr(idx), 'Location', 'SouthEast');
    axis('ij')
    set(findall(hF2,'-property','FontSize'),'FontSize',FontSize)
end

%% Plot error comparison
if C.NumTrials > 1 && UseSimData && CalcErr
    dat = squeeze(SSE);
    leg = {EstMethod};
    if CalcOpt
        dat = cat(2,dat, squeeze(SSEopt));
        leg = cat(2,leg,'Optimal');
    end
    if CalcIdeal
        dat = cat(2,dat, squeeze(SSEideal));
        leg = cat(2,leg,'Ideal');
    end
    hF3 = figure;
    title('Comparison of Estimation Error')
    boxplot(dat,'notch','on','labels',leg)
    ylabel('||x - x_{true}||/||x_{true}||');
    set(findall(hF3,'-property','FontSize'),'FontSize',FontSize)
end

%% Plot Quality of regularization coefficient (needs to calculate optimal)

if C.NumTrials > 1 && UseSimData && CalcOpt
    hF4 = figure;
    boxplot(C.RegLambda./C.OptimalLambda,'notch','on','labels',{EstMethod})
    ylabel('\lambda/\lambda_{opt}')
    title('Quality of Regularization Parameter')
    set(findall(hF4,'-property','FontSize'),'FontSize',FontSize)
end

%% Plot Resolution matrix
if PlotRes
    C.GenResMat(0);
    hF5 = figure;
    imagesc(C.ReadOutRegion, C.ReadOutRegion, C.ResMat)
    xlabel('Position of \delta source'); ylabel('Resolution');
    title('Resolution using \delta sources without regularization (\lambda = 0)')
    addline(C.ElectrodePositions','v', 'color', 'k', 'Linestyle', ':');
    addline([0 0],'vh', 'color', 'g', 'Linestyle', ':');
    colorbar;
    set(findall(hF5,'-property','FontSize'),'FontSize',FontSize)
    
    C.GenResMat(C.RegLambda(Trial));
    hF6 = figure;
    imagesc(C.ReadOutRegion, C.ReadOutRegion, C.ResMat)
    xlabel('Position of \delta source'); ylabel('Resolution');
    title(['Resolution using \delta sources of Trial ' num2str(Trial) ' (\lambda = ' num2str(C.RegLambda(Trial),3) ')'])
    addline(C.ElectrodePositions','v', 'color', 'k', 'Linestyle', ':');
    addline([0 0],'vh', 'color', 'g', 'Linestyle', ':');
    colorbar;
    set(findall(hF6,'-property','FontSize'),'FontSize',FontSize)
end

%% Plot Specific Positions of the resolution matrix

if PlotRes
    C.GenResMat(C.RegLambda(Trial));
    ElIdx = [1 5 10 15 20 25 30]; % Which Electrode Positions should be plotted
    PosIdx = C.ElectrodeIdx(ElIdx);
    PosIdx = sort([PosIdx; round(conv(PosIdx,[0.5 0.5],'valid'))]);
    cmap = jet(length(PosIdx));
    leg = cell(length(PosIdx),1);
    hF7 = figure;
    hold on
    for i = 1:length(PosIdx)
        plot(C.ReadOutRegion, C.ResMat(:,PosIdx(i)),'color',cmap(i,:),'LineWidth', 2);
        leg{i} = ['Pos = ' num2str(C.ReadOutRegion(PosIdx(i))) ' mm'];
    end
    xlabel('Position of \delta source'); ylabel('Source Density (\muA/mm^3)');
    addline([0 0],'vh', 'color', 'g', 'Linestyle', ':');
    legend(leg,'Location','NorthEast');
    title('Selected Columns from Resolution Matrix')
    xlim(C.ReadOutRegion([1 end]))
    set(findall(hF7,'-property','FontSize'),'FontSize',FontSize)
end
