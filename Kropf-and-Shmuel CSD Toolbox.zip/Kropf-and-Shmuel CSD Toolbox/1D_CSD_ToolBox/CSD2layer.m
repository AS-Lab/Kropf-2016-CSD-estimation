classdef CSD2layer < handle
    
    properties % General Properties
        
        NumSamples; % Number of Time Points
        
        NumTrials; % Number of trials
        
        ElectrodePositions; % in mm (Bad Channels Removed)
        
        BadChannels; % Indices of Bad Channels
        
        ReadOutRegion; % At which positions should the CSD be calculated - in mm
        
        RegularizationMethod; % e.g. cross-validation
        
        RegNoiseEst; % Estimate of the noise amplitude for regularization. (scalar if same for all electrodes or vector if different)
        
        RegLambda; % Regularization Parameter
        
        RegFail; % [Default = false] Logical Flag to indicate possible failure of the regularization
        
        RegOutlier; % [Default = false] Logical Flag indicating that the ratio between optimal lambda and found lambda is > 5 (only with surrogate CSD)
        
        Rho; % Residual Misfit
        
        Eta; % Solution Norm or SemiNorm
        
        EtaBound; % Upper bound on the solution norm when looking for l_curve corner
        
        RegLambdaZero; % Initial value used for regularization parameter
        
        SimPotObj; % Simulate Potential Object (It will automatically copy the Potential when set)
        
        InterpPot = false; % Interpolate potential of BadChannels instead of removing them
        
        InterpMethod; % Method used for interpolation ('nearest', 'linear', 'spline', 'pchip')
        
        TextOutput;
        
    end
    
    properties % Assumed Source and Medium Properties
        
        SourceShape; % Lateral Shape of the source (either 'Uniform', 'Gaussian' or '2-deriv)
        
        Diameter; % in mm
        
        NumLayers = 1; % Number of layers in medium (1,2, or 3)
        
        TopCond; % Conductivity of top medium in S/m
        
        ExCond = 0.3; % Conductivity of extracellular medium in S/m
        
        BottomCond; % Conductivity of bottom medium in S/m
        
        WhiteMatterDepth; % Depth of transition between middle to third medium
        
        N = 20; % Number of image source levels in calculating three-layered medium
        
    end
    
    properties (Transient = true) % Not saved when object is saved
        
        Pot; % Potential in mV - indexed at electrodes * time * trials
        
    end
    
    properties (SetAccess = protected)
        
        OriginalElPos; % All ElectrodePositions without Bad Channels Removed
        
        F; % F matrix (called KPot in kCSD)
        
        U; % Left singular vectors of F
        
        sm; % Singular values of F
        
        X; % Right singular vectors of F
        
        H; % Regularization matrix
        
        BasisWeights;
        
        CSDest; % Estimated CSD in uA/mm^3
        
        ResMat; % Resolution matrix (NumReadOut, NumReadOut)
        
        DataMisfit; % ||F*m-d||
        
        IdealBasisWeights; % Weights found using the Real CSD function (only with surrogate data function)
        
        IdealCSDest; % Estimated CSD from Ideal weights in uA/mm^3
        
        OptimalLambda;% Best possible Lambda that can be found using the chosen prior and regularization scheme (only with surrogate data function)
        
        OptimalBasisWeights; % Weights estimated using Ideal Lambda
        
        OptimalCSDest; % Estimated CSD with Optimal Lambda in uA/mm^3
        
        OptimalEstErr; % The difference between estimate and RealCSD (only with surrogate data)
        
        IdealEstErr; % The difference between estimate and RealCSD (only with surrogate data)
        
        EstErr; % The difference between estimate and RealCSD (only with surrogate data)
        
        PotErr; % The difference between the noise free pot and the potential estimated from the weights (only surrogate data))
        
        CSDestMethod; % Method used for the CSD estimation
        
        ForwardFunc; % Function handle describing the forward operator. Depends on the SourceShape.
        
        Filtered = false; % Was the estimated CSD spatially filtered (NOT IMPLEMENTED YET)
        %(FILTER COULD BE IMPLEMENTED IN A DIFFERENT FUNCTION WHICH RETURNS
        %THE FILTERED DATA)
    end
    
    properties (Dependent = true)
        
        NumEl; % Number of electrodes
        
        ElectrodeIdx; % Index of electrode in the ReadOutRegion
        
        LastElOut; % Index of last electrode outside of the brain
        
        NumReadOut; % Number of points where the CSD is calculated
        
        LastOutReadOut; % Last point outside of the brain in the ReadOutRegion
        
        ReadOutSampling; % Median distance between sampling points
        
        RegularSpacedReadOut; % Flag measuring whether the ReadOutRegion is regularly sampled
        
        R; % in mm (R = Diameter/2)
        
    end
    
    methods %(Abstract = true) % To be defined by subclasses
        
        CalcF(C); % Find the F matrix
        
        CalcCSDest(C, ReadOutRegion);
        
        CalcResMat(C, weights);
        
        FindIdealWeights(C);
        
        ResetReadOutClassSpecific(C);
        
    end
    
    methods % Constructor
        
        function C = CSD2layer(ElectrodePositions, Params, TextOutput) % class constructor
            
            if ~exist('TextOutput','var'), C.TextOutput = true; else C.TextOutput = TextOutput; end
            if isfield(Params, 'BadChannels') && ~isempty(Params.BadChannels)
                C.BadChannels = Params.BadChannels;
            else
                C.BadChannels = [];
            end
            if isfield(Params, 'InterpPot') && ~isempty(Params.InterpPot)
                C.InterpPot = true; % Potential will be interpolated
                C.InterpMethod = Params.InterpPot;
            else
                C.InterpPot = false;
            end
            if ~exist('BadChannels','var'), C.BadChannels = []; else C.BadChannels = Params.BadChannels; end
            C.OriginalElPos = ElectrodePositions(:);
            
            if C.InterpPot && ~isempty(C.BadChannels)
                C.InterpMethod = InterpMet;
                C.ElectrodePositions = ElectrodePositions;
            else
                C.ElectrodePositions = ElectrodePositions(setdiff(1:length(C.OriginalElPos),C.BadChannels));
            end
            
            C.ElectrodePositions = C.ElectrodePositions(:); % Making sure it is a column vector
            
            C.Diameter = Params.Diameter;
            
            C.SourceShape = Params.SourceShape;
            
            C.NumLayers = Params.NumLayers;
            
            switch C.NumLayers
                case 1
                    C.TopCond = [];
                    C.ExCond = Params.ExCond;
                    C.BottomCond = [];
                    
                case 2
                    C.TopCond = Params.TopCond;
                    C.ExCond = Params.ExCond;
                    C.BottomCond = [];
                    
                case 3
                    C.TopCond = Params.TopCond;
                    C.ExCond = Params.ExCond;
                    C.BottomCond = Params.BottomCond;
                    C.WhiteMatterDepth = Params.WhiteMatterDepth;
                    if isfield(Params, 'N') && ~isempty(Params.N)
                        C.N = Params.N;
                    end
            end
            
            SetForwardFunc(C);
            
        end
        
    end
    
    methods
        
        function CalcFmat(C)
            if C.TextOutput
                fprintf(['Calculating ' C.CSDestMethod ' F-Matrix...'])
                tstart = tic;
            end
            
            C.CalcF;
            
            if C.TextOutput
                t = toc(tstart);
                fprintf('%4g seconds \n', t);
            end
        end
        
        function EstimateWeightsHansen(C, RegParam)
            
            % Prior (only implemented for Hansen's toolbox so far):
            % 0: L = I
            % 1: L = first derivative
            % [1 2] = first and second derivative prior (not implemented
            % yet for iCSD, kCSD and qCSD)
            
            C.ResetPotVars;
            
            if isfield(RegParam,'Prior')
                Prior = RegParam.Prior;
            else
                Prior = [];
            end
            if isfield(RegParam,'ExtraReg')
                ExtraReg = RegParam.ExtraReg;
                if ExtraReg
                    ExtraRegRegions = RegParam.ExtraRegRegions;
                else
                    ExtraRegRegions = [];
                end
            else
                ExtraReg = false;
                ExtraRegRegions = [];
            end
            if isfield(RegParam,'TrialWise')
                trialwise = RegParam.TrialWise;
            else
                trialwise = true;
            end
            if isfield(RegParam,'RegMethod')
                RegMethod = RegParam.RegMethod;
            else
                RegMethod = 'tikhonov';
            end
            if isfield(RegParam,'LambdaMethod')
                LambdaMethod = RegParam.LambdaMethod;
            else
                LambdaMethod = 'l_curve';
            end
            if isfield(RegParam,'EtaBound')
                C.EtaBound = RegParam.EtaBound;
            else
                C.EtaBound = [];
            end
            if isfield(RegParam,'PriorType')
                PriorType = RegParam.PriorType;
            else
                PriorType = 'Coeff';
            end
            
            if isnumeric(Prior)
                if isempty(Prior)
                    C.H = 0;
                else
                    C.H = C.CalcNormMat(Prior, PriorType, ExtraReg, ExtraRegRegions);
                end
            end
            
            if C.TextOutput
                fprintf(['Estimating ' C.CSDestMethod ' Weights...'])
                tstart = tic;
            end
            
            C.RegularizationMethod = {lower(RegMethod(1:4)),lower(LambdaMethod)};
            if strcmpi(LambdaMethod,'user_specified')
                C.FindLambdaHansen(lower(RegMethod(1:4)), RegParam.RegLambda, '');
            else
                C.FindLambdaHansen(lower(RegMethod(1:4)), lower(LambdaMethod), trialwise);
            end
            
            if C.TextOutput
                if strcmpi(LambdaMethod,'user_specified')
                    fprintf('(Regularization Lambda Specified by User: Mean Lambda = %g)...', mean(C.RegLambda));
                else
                    if trialwise
                        fprintf(strcat('(Regularization Lambda Found Separately for each TimePoint through ', RegMethod, ' ', LambdaMethod, ': Mean Lambda = %g)...'), mean(mean(C.RegLambda)));
                    else
                        fprintf(strcat('(Single Regularization Lambda Found for all TimePoints and Trials through ', RegMethod, ' ', LambdaMethod, ': Mean Lambda = %g)...'), mean(mean(C.RegLambda)));
                    end
                end
                t = toc(tstart);
                fprintf('%4g seconds \n', t);
            end
            
        end
        
        function GenCSDest(C, ReadOutRegion)
            
            %% Input
            % ReadOutRegion: Position where the CSD should be calculated.
            % If it is left empty, the CSD is calculated at the
            % ElectrodePostions without the BadChannels removed
            
            %% Computation
            
            if nargin == 1 || isempty(ReadOutRegion)
                C.ReadOutRegion = C.OriginalElPos;
            else
                C.ReadOutRegion = ReadOutRegion;
            end
            
            if C.TextOutput
                fprintf(['Generating ' C.CSDestMethod ' estimate...'])
                tstart = tic;
            end
            
            C.CSDest = C.CalcCSDest(C.BasisWeights);
            
            if C.TextOutput
                t = toc(tstart);
                fprintf('%4g seconds \n', t);
            end
            
        end
        
        function GenOptimalCSDest(C, ReadOutRegion)
            
            %% Input
            % ReadOutRegion: Position where the CSD should be calculated.
            % If it is left empty, the CSD is calculated at the
            % ElectrodePostions without the BadChannels removed
            
            % This function doesn't reset the ReadOutRegion if
            % C.ReadOutRegion is not empty
            
            %% Computation
            
            if isempty(C.ReadOutRegion)
                if nargin == 1 || isempty(ReadOutRegion)
                    C.ReadOutRegion = C.OriginalElPos;
                else
                    C.ReadOutRegion = ReadOutRegion;
                end
            end
            
            if C.TextOutput
                fprintf(['Generating Optimal ' C.CSDestMethod ' estimate...'])
                tstart = tic;
            end
            
            C.OptimalCSDest = C.CalcCSDest(C.OptimalBasisWeights);
            
            if C.TextOutput
                t = toc(tstart);
                fprintf('%4g seconds \n', t);
            end
            
        end
        
        function GenIdealCSDest(C, ReadOutRegion)
            
            %% Input
            % ReadOutRegion: Position where the CSD should be calculated.
            % If it is left empty, the CSD is calculated at the
            % ElectrodePostions without the BadChannels removed
            
            % This function doesn't reset the ReadOutRegion if
            % C.ReadOutRegion is not empty
            
            %% Computation
            
            if isempty(C.ReadOutRegion)
                if nargin == 1 || isempty(ReadOutRegion)
                    C.ReadOutRegion = C.OriginalElPos;
                else
                    C.ReadOutRegion = ReadOutRegion;
                end
            end
            
            if C.TextOutput
                fprintf(['Generating Ideal (i.e. Noise-Free) ' C.CSDestMethod ' estimate...'])
                tstart = tic;
            end
            
            C.IdealCSDest = C.CalcCSDest(C.IdealBasisWeights);
            
            if C.TextOutput
                t = toc(tstart);
                fprintf('%4g seconds \n', t);
            end
            
        end
        
        function GenResMat(C, Lambda, D)
            if C.TextOutput
                fprintf(['Generating ' C.CSDestMethod ' Resolution Matrix...'])
                tstart = tic;
            end
            
            if nargin < 3
                R = C.R;
            else
                R = D/2;
            end
            
            
            deltaPot = nan(C.NumEl, C.NumReadOut);
            for el = 1:C.NumEl
                deltaPot(el,:) = C.ForwardFunc(C.ReadOutRegion,C.ElectrodePositions(el),R)*C.ReadOutSampling;
            end
            
            if size(C.F,1) > C.NumEl % Add an imaginary zero potential at the top and bottom for the iCSD spline method
                deltaPot = cat(1,zeros(1, size(deltaPot,2)), deltaPot, zeros(1, size(deltaPot,2)));
            end
            
            res_weights = nan(size(C.F,2), C.NumReadOut);
            for i = 1:C.NumReadOut
                res_weights(:,i) = C.GetWeights(Lambda, deltaPot(:,i), C.RegularizationMethod{1});
            end
            
            C.CalcResMat(res_weights);
            
            if C.TextOutput
                t = toc(tstart);
                fprintf('%4g seconds \n', t);
            end
        end
        
        function Data = AdaptDataForWeightEst(C, Data) 
            % This function is useful to estimate weights on a new
            % Potential Vector that hasn't undergone the initial
            % conditioning
            if ~isempty(C.BadChannels)
                if ~C.InterpPot
                    Data = Data(setdiff(1:length(C.OriginalElPos), C.BadChannels),:,:);
                end
            end
            
            if size(C.F,1) > C.NumEl % Add an imaginary zero potential at the top and bottom for the iCSD spline method
                Data = cat(1,zeros(1, size(Data,2)), Data, zeros(1, size(Data,2)));
            end 
        end
        
    end
    
    methods % Set Methods
        
        function SetForwardFunc(C)
            
            if ~strcmpi(C.SourceShape,'infplane')
                switch lower(C.SourceShape)
                    case 'unicyl'
                        ForwardF = @(zs,ze,R) 1/2*(sqrt(R^2+(ze-zs).^2) - abs(ze-zs));
                    case 'gaussian'
                        ForwardF = @(zs,ze,R) 1/2*(sqrt(2*pi)*R/2).*erfcx(abs(ze-zs)/(sqrt(2)*R));
                    case 'point'
                        ForwardF = @(zs,ze,R) 1/(4*pi)*(1./sqrt(R^2+(ze-zs).^2));
                end
                
                switch C.NumLayers
                    case 1
                        fun = @(zs,ze,R) CSD2layer.Pot1Layer(zs,ze,R,C.ExCond,ForwardF);
                    case 2
                        fun = @(zs,ze,R) CSD2layer.Pot2Layer(zs,ze,R,C.TopCond,C.ExCond,ForwardF);
                    case 3
                        a = C.WhiteMatterDepth/2;
                        fun = @(zs,ze,R) CSD2layer.Pot3LayerParallel(zs,ze,R, C.TopCond,C.ExCond, C.BottomCond,ForwardF, a, C.N);
                end
                
            else
                
                exCond = C.ExCond;
                
                topCond = C.TopCond;
                
                % ze = position of the electrode
                % zs = position of source
                switch lower(C.SourceShape)
                    
                    case 'infplane'
                        
                        if length(C.Diameter) > 1
                            Lb = C.Diameter(1);%-10^2;
                            Lt = C.Diameter(2);%10^2;
                        else
                            offset = mean(C.ElectrodePositions([1 end]));
                            
                            R = C.Diameter/2;
                            %                         ChanSep = median(diff(C.ElectrodePositions));
                            %                         L = R + 1/((1+ChanSep)*R) - 3*ChanSep/R^2;
                            %                         if L < el_l
                            el_l =  abs(diff(C.ElectrodePositions([1 end])))/2; % half length of electrode
                            L = R + el_l;
                            %                         end
                            
                            Lb = offset-L;%-10^2;
                            Lt = offset+L;%10^2;
                            %                         Lb = -(C.Diameter/2+abs(C.ElectrodePositions(1)));%-10^2;
                            %                         Lt = C.Diameter/2+abs(C.ElectrodePositions(end));%10^2;
                        end
                        %                     Vb = -0.1554;%-0.0497;%-0.6671;
                        %                     Vt = -0.4808;%-0.3218;%-1.0329;
                        fun = @(zs,ze,R) (-1/(exCond*(Lt - Lb))*(...
                            (Lt-zs).*(Lb-ze).*(ze>=0 & ze<=zs) + ...
                            (Lb-zs).*(Lt-ze).*(ze>zs & ze<=Lt) + ...
                            (exCond - topCond)/(Lt*topCond - Lb*exCond)*Lb*(Lt-zs).*(Lt-ze)).*(ze>=0 & ze<=Lt) - ...
                            (1/(Lt*topCond - Lb*exCond)*(Lt-zs).*(Lb-ze)).*(ze<0 & ze>=Lb)).*(zs>=0 & zs<=Lt) + ...
                            ...
                            (-1/(topCond*(Lt-Lb))*(...
                            (Lt-zs).*(Lb-ze).*(ze>=Lb & ze<zs) + ...
                            (Lb-zs).*(Lt-ze).*(ze>=zs & ze<0) + ...
                            (exCond - topCond)/(Lt*topCond - Lb*exCond)*Lt*(Lb-zs).*(Lb-ze).*(ze>=Lb & ze<0)) - ...
                            (1/(Lt*topCond - Lb*exCond)*(Lb-zs).*(Lt-ze)).*(ze>=0 & ze<=Lt)).*(zs<0 & zs>=Lb);
                        
                    case 'point'
                        
                        fun = @(zs,ze,R) (1/(4*pi*exCond)*(1./sqrt((zs - ze).^2).*(abs(zs-ze)>=10^-3)+...
                            1./sqrt((10^-3).^2).*(abs(zs-ze)<10^-3) +...
                            (exCond-topCond)/(exCond + topCond)*(1./sqrt((zs + ze).^2))).*(zs>=0) + ...
                            1/(2*pi*(exCond + topCond))*(1./sqrt((zs - ze).^2)).*(zs<0)).*(ze>=0) + ...
                            ...
                            (1/(4*pi*topCond)*(1./sqrt((zs - ze).^2).*(abs(zs-ze)>=10^-3)+...
                            1./sqrt((10^-3).^2).*(abs(zs-ze)<10^-3) +...
                            (topCond-exCond)/(exCond + topCond)*(1./sqrt((zs + ze).^2))).*(zs<=0) + ...
                            1/(2*pi*(exCond + topCond))*(1./sqrt((zs - ze).^2)).*(zs>0)).*(ze<0);
                        
                end
            end
            
            C.ForwardFunc = fun;
            
        end
        
        function SetF(C,F)
            C.F = F;
        end
        
        function SetBasisWeights(C,weights)
            
            C.ResetPotVars;
            
            C.BasisWeights = weights;
            
        end
        
        function SetPotential(C,pot) % Needs to be used to handle bad channels properly
            
            if ~isempty(C.BadChannels)
                if C.InterpPot % Interpolate Potential
                    el_pos = C.ElectrodePositions(setdiff(1:length(C.OriginalElPos), C.BadChannels));
                    if size(pot,1) ~= C.NumEl - length(C.BadChannels) % Provided potential has more channels than the provided number of electrodes minus the # of bad channels
                        if size(pot,1) == C.NumEl % The original potential without the bad channels removed has been provided
                            pot = pot(setdiff(1:length(C.OriginalElPos), C.BadChannels),:,:);
                        else
                            error('The first dimension of the provided potential does not fit the # of electrodes');
                        end
                    end
                    C.Pot = interp1(el_pos', pot, C.OriginalElPos, C.InterpMethod);
                    if C.TextOutput
                        disp(['The potential has been interpolated at channels ' num2str(C.BadChannels) ' using the ' C.InterpMethod ' method'])
                    end
                else
                    C.Pot = pot(setdiff(1:length(C.OriginalElPos), C.BadChannels),:,:);
                end
            else
                C.Pot = pot;
            end
            
            C.ResetPotVars;
            
        end
        
        function set.ReadOutRegion(C, ReadOutRegion)
            C.ReadOutRegion = ReadOutRegion;
            C.ResetReadOutVars;
        end
        
        function set.SimPotObj(C, SimPotObj)
            C.SimPotObj = SimPotObj;
            C.SetPotential(SimPotObj.Pot);
        end
        
    end
    
    methods % Error Methods
        
        function CalculateEstErr(C)
            
            if ~isempty(C.SimPotObj) && ~isempty(C.SimPotObj.RealCSD)
                if ~isempty(C.CSDest)
                    C.EstErr = C.CSDest - repmat(reshape(C.SimPotObj.SourceInt,[1 size(C.SimPotObj.SourceInt)]),[length(C.ReadOutRegion),1,1]).*repmat(C.SimPotObj.RealCSD(C.ReadOutRegion)',[1 C.NumSamples C.NumTrials]);
                else
                    C.EstErr = [];
                end
                
            else
                C.EstErr = [];
            end
        end
        
        function CalculateOptimalEstErr(C)
            
            if ~isempty(C.SimPotObj) && ~isempty(C.SimPotObj.RealCSD)
                if ~isempty(C.OptimalCSDest)
                    C.OptimalEstErr = C.OptimalCSDest - repmat(reshape(C.SimPotObj.SourceInt,[1 size(C.SimPotObj.SourceInt)]),[length(C.ReadOutRegion),1,1]).*repmat(C.SimPotObj.RealCSD(C.ReadOutRegion)',[1 C.NumSamples C.NumTrials]);
                else
                    C.OptimalEstErr = [];
                end
                
            else
                C.OptimalEstErr = [];
            end
        end
        
        function CalculateIdealEstErr(C)
            
            if ~isempty(C.SimPotObj) && ~isempty(C.SimPotObj.RealCSD)
                if ~isempty(C.OptimalCSDest)
                    C.IdealEstErr = C.IdealCSDest - repmat(reshape(C.SimPotObj.SourceInt,[1 size(C.SimPotObj.SourceInt)]),[length(C.ReadOutRegion),1,1]).*repmat(C.SimPotObj.RealCSD(C.ReadOutRegion)',[1 C.NumSamples C.NumTrials]);
                else
                    C.IdealEstErr = [];
                end
                
            else
                C.IdealEstErr = [];
            end
        end
        
        function FindMinCSDEstErr(C,ReadOutRegion)
            
            if nargin == 1 || isempty(ReadOutRegion)
                C.ReadOutRegion = C.OriginalElPos;
            else
                C.ReadOutRegion = ReadOutRegion;
            end
            
            CSDerr = @(lambdaReg) C.MinCSDEstErr(abs(lambdaReg));
            
            output = C.TextOutput;
            
            C.TextOutput = false;
            
            C.RegLambda = fminbnd(CSDerr, 0, 1, optimset('TolX',1e-12));
            if  C.RegLambda < 1e-12
                C.RegLambda = 0;
            end
            
            C.TextOutput = output;
        end
        
        function err = MinCSDEstErr(C, Lambda)
            ReadOutSpacing = median(diff(C.ReadOutRegion));
            
            C.EstimateWeights(Lambda);
            C.GenCSDest(C.ReadOutRegion);
            C.CalculateEstErr;
            err = mean(C.EstErr.^2/ReadOutSpacing);
        end
        
        function CalculatePotErr(C)
            
            if ~isempty(C.SimPotObj) && ~isempty(C.SimPotObj.NoiseFreePot)
                if ~isempty(C.BasisWeights)
                    RealPot = C.SimPotObj.NoiseFreePot;
                    Pot_est = C.F*reshape(C.BasisWeights, [size(C.F,1), C.NumSamples*C.NumTrials]);
                    
                    if size(RealPot,1) < size(C.F,1) % spline case
                        C.PotErr = RealPot - Pot_est(2:end-1,:);
                    else
                        C.PotErr = RealPot - Pot_est;
                    end
                else
                    C.PotErr = [];
                end
                
            else
                C.PotErr = [];
            end
        end
        
    end
    
    methods % Lambda Methods
        
        function InspectInverse_Hansen(C, params)
            % This function can be used to inspect the quality of the
            % estimation procedure
            if exist('params','var')
                if ~isfield(params, 'Fs'), Fs = 1;end
                if isfield(params,'Samples') && ~isempty(params.Samples)
                    samples = params.Samples;
                else
                    samples = 1:C.NumSamples;
                end
                if isfield(params,'Trials') && ~isempty(params.Trials)
                    trials = params.Trials;
                else
                    trials = 1:C.NumTrials;
                end
            else
                Fs = 1;
                samples = 1:C.NumSamples;
                trials = 1:C.NumTrials;
            end
            
            ps = size(C.sm,2);
            
            
            if length(trials) == 1
                cmap = [1 0 0];
            else
                cmap = jet(length(trials));
            end
            
            hF = figure;
            if length(samples) > 1 % Use imagesc
                subplot(2,3,1) % Average (over trials) potential
                amp = max(abs([max(max(mean(C.Pot(:,samples,trials),3))) min(min(mean(C.Pot(:,samples,trials),3)))]));
                imagesc((samples - 1)/Fs, C.ElectrodePositions, mean(C.Pot(:,samples,trials),3),[-amp amp]);
                
                subplot(2,3,4) % Average (over trials) estimated CSD
                amp = max(abs([max(max(mean(C.CSDest(:,samples,trials),3))) min(min(mean(C.CSDest(:,samples,trials),3)))]));
                imagesc((samples - 1)/Fs, C.ReadOutRegion, mean(C.CSDest(:,samples,trials),3),[-amp amp])
                
                while true
                    try
                        [x, y] = ginput(1);
                        x = round(x);
                        if x < 1 || x > C.NumSamples
                            disp('Not accessible point. Only click on the first subplot')
                        else
                            for i = trials
                                data = C.Pot(:,x,i);
                                csd_est = C.CSDest(:,x,i);
                                
                                subplot(2,3,2) % Potential at each trial
                                if i > 1, hold on; end
                                plot(data,C.ElectrodePositions,'color',cmap(i,:));
                                axis('ij');
                                ylim([C.ElectrodePositions(1) C.ElectrodePositions(end)]);
                                addline([0 0],'hv','color', 'g');
                                if i == C.NumTrials, hold off; end
                                
                                subplot(2,3,5) % CSDestimate at each trial
                                if i > 1, hold on; end
                                plot(csd_est,C.ReadOutRegion,'color',cmap(i,:));
                                axis('ij');
                                addline([0 0],'hv','color', 'g');
                                if i == C.NumTrials, hold off; end
                                
                                if size(C.F,1) > length(data)
                                    data = [0; data; 0];
                                end
                                subplot(2,3,3) % Picard for each trial
                                if i > 1, hold on; end
                                picard(C.U,C.sm,data);
                                if i == C.NumTrials, hold off; end
                                
                                subplot(2,3,6) % L-curve or gcv for each trial
                                if i > 1, hold on; end
                                switch C.RegularizationMethod{2}
                                    case 'l_curve'
                                        [reg_corner,rho,eta,reg_param, rho_c,eta_c] = C.L_curve_Hansen(C.U,C.sm,data,C.RegularizationMethod{1});
                                        CSD2Layer.Plot_L_curve(eta,rho,'-', ps,reg_param, cmap(i,:), rho_c,eta_c);
                                        title(['L-curve, ',C.RegularizationMethod{1},' corner at ',num2str(reg_corner)]);
                                    case 'gcv'
                                        [reg_min,G,reg_param] = C.GCV_Hansen(C.U,C.sm,data,C.RegularizationMethod{1});
                                        CSD2Layer.Plot_GCV( reg_min, G,reg_param, C.RegularizationMethod{1}, cmap(i,:))
                                    case 'ncp'
                                        [reg_min,dist,reg_param] = ncp(C.U,C.sm,data,C.RegularizationMethod{1});
%                           
                                end
                                if i == C.NumTrials, hold off; end
                            end
                        end
                    catch ME
                        DisplayErrorMessage(ME);
                        
                        return;
                    end
                end
            else % Plot the result because only 1 time point
                if length(trials) > 1
                    
                    subplot(2,3,1) % Average (over trials) potential
                    plot(mean(C.Pot(:,samples,trials),3), C.ElectrodePositions);
                    hold on; plot(mean(C.Pot(:,samples,trials),3), C.ElectrodePositions, 'color', 'k', 'LineWidth',3);hold off
                    title('Potential')
                    axis('ij');
                    ylim([C.ElectrodePositions(1) C.ElectrodePositions(end)]);
                    addline([0 0],'hv','color', 'g');
                    
                    subplot(2,3,4) % Average (over trials) estimated CSD
                    plot(mean(C.CSDest(:,samples,trials),3), C.ReadOutRegion)
                    hold on; plot(mean(C.CSDest(:,samples,trials),3), C.ReadOutRegion, 'color', 'k', 'LineWidth',3);hold off
                    title('CSD estimate')
                    axis('ij');
                    ylim([C.ReadOutRegion(1) C.ReadOutRegion(end)]);
                    addline([0 0],'hv','color', 'g');
                    
                else % only one trial
                    
                    subplot(2,2,1) % Average (over trials) potential
                    plot(C.Pot(:,samples,trials),C.ElectrodePositions, 'color', cmap(1,:), 'LineWidth',3);
                    title('Potential');
                    axis('ij');
                    ylim([C.ElectrodePositions(1) C.ElectrodePositions(end)]);
                    addline([0 0],'hv','color', 'g');
                    
                    subplot(2,2,3) % Average (over trials) estimated CSD
                    plot(C.CSDest(:,samples,trials), C.ReadOutRegion, 'color', cmap(1,:), 'LineWidth',3)
                    title('CSD estimate');
                    axis('ij');
                    ylim([C.ReadOutRegion(1) C.ReadOutRegion(end)]);
                    addline([0 0],'hv','color', 'g');
                    
                    
                    data = squeeze(C.Pot(:,samples,trials));
                    
                    if size(C.F,1) > length(data)
                        data = [0; data; 0];
                    end
                    
                    subplot(2,2,2) % Picard
                    picard(C.U,C.sm,data);
                    
                    
                    subplot(2,2,4) % L-curve or gcv for each trial
                    
                    Bound = C.EtaBound;
                    switch C.RegularizationMethod{2}
                        case 'l_curve'
                            [reg_corner,rho,eta,reg_param, rho_c,eta_c] = C.L_curve_Hansen(C.U,C.sm,data,C.RegularizationMethod{1}, Bound);
                            CSD2Layer.Plot_L_curve(eta,rho,'-', ps,reg_param, 'k', rho_c,eta_c);
                            title(['L-curve, ',C.RegularizationMethod{1},' corner at ',num2str(reg_corner)]);
                        case 'gcv'
                            [reg_min,G,reg_param] = C.GCV_Hansen(C.U,C.sm,data,C.RegularizationMethod{1});
                            CSD2Layer.Plot_GCV(reg_min, G,reg_param, C.RegularizationMethod{1}, 'k')
                        case 'ncp'
                            [reg_min,dist,reg_param] = ncp(C.U,C.sm,data,C.RegularizationMethod{1});
                            
                    end
                    
                    
                    
                end
            end
            
        end
        
        function FindLambdaHansen(C,reg_method,lambda_method, trialwise)
            
            if C.H == 0;
                [U,sm,X] = csvd(C.F);
            else
                [U,sm,X] = cgsvd(C.F, C.H);
            end
            C.U = U;
            C.sm = sm;
            C.X = X;
            H = C.H;
            
            pot = reshape(C.Pot, [C.NumEl C.NumSamples*C.NumTrials]);
            
            if size(C.F,1) > C.NumEl % Add an imaginary zero potential at the top and bottom for the iCSD spline method
                pot = cat(1,zeros(1, size(pot,2)), pot, zeros(1, size(pot,2)));
            end
            
            if strcmpi(C.RegularizationMethod{2}, 'user_specified')
                if length(lambda_method) == size(pot,2)
                    RegLambda = lambda_method(:)';
                elseif length(lambda_method) == 1
                    RegLambda = lambda_method*ones(1,size(pot,2));
                else
                    error('Length of Regularization parameter is not correct');
                end
                C.RegLambda = RegLambda;
            else
                Bound = C.EtaBound;%10; 0.3; %0.08;
                
                if trialwise
                    RegLambda = nan(1, size(pot,2));
                    RegFail = reshape(C.RegFail, [1 C.NumSamples*C.NumTrials]);
                    for i = 1:size(pot,2)
                        hF = figure('Visible','off');
                        
                        if strcmpi(lambda_method, 'l_curve')
                            
                            [RegLambda(i),rho,eta,reg_param] = CSD2layer.L_curve_Hansen(U,sm,pot(:,i),reg_method, Bound);
                            
                            if isempty(Bound);
                                idx = length(reg_param);
                            else
                                idx = find(eta<Bound,1,'last');
                            end
                            if RegLambda(i) == reg_param(idx)
                                RegFail(i) = true; % The regularization parameter was set to the first point
                            else
                                RegFail(i) = false;
                            end
                            
                        elseif strcmpi(lambda_method, 'gcv')
%                             [RegLambda(i),G,reg_param]  = CSD2layer.GCV_Hansen(U,sm,pot(:,i),reg_method);
                            [RegLambda(i),G,reg_param]  = gcv(U,sm,pot(:,i),reg_method);
                            if RegLambda(i) == reg_param(end)
                                RegFail(i) = true; % The regularization parameter was set to the first point
                            else
                                RegFail(i) = false;
                            end
                            
                        elseif strcmpi(lambda_method, 'quasi')
                            
                            [RegLambda(i),Q,reg_param]  = quasiopt(U,sm,pot(:,i),reg_method);
                            
                            if RegLambda(i) == reg_param(end)
                                RegFail(i) = true; % The regularization parameter was set to the first point
                            else
                                RegFail(i) = false;
                            end
                        elseif strcmpi(lambda_method, 'ncp')
                            
                            [RegLambda(i),G,reg_param]  = ncp(U,sm,pot(:,i),reg_method);
                            
                            if RegLambda(i) == reg_param(end)
                                RegFail(i) = true; % The regularization parameter was set to the first point
                            else
                                RegFail(i) = false;
                            end
                        end
                        close(hF)
                    end
                else
                    hF = figure('Visible','off');
                    
                    if C.H == 0;
                        [U1,sm1,X1] = csvd(repmat(C.F,C.NumSamples*C.NumTrials,1));
                    else
                        [U1,sm1,X1] = cgsvd(repmat(C.F,C.NumSamples*C.NumTrials,1), C.H);
                    end
                    pot1 = reshape(pot, [numel(pot) 1]);
                    
                    if strcmpi(lambda_method, 'l_curve')
                        
                        [RegLambda,rho,eta,reg_param] = CSD2layer.L_curve_Hansen(U1,sm1,pot1,reg_method, Bound);
                        
                        if isempty(Bound);
                            idx = length(reg_param);
                        else
                            idx = find(eta<Bound,1,'last');
                        end
                        if RegLambda == reg_param(idx)
                            RegFail = true; % The regularization parameter was set to the first point
                        else
                            RegFail = false;
                        end
                        
                    elseif strcmpi(lambda_method, 'gcv')
                        [RegLambda,G,reg_param]  = CSD2layer.GCV_Hansen(U1,sm1,pot1,reg_method);
                        if RegLambda == reg_param(end)
                            RegFail = true; % The regularization parameter was set to the first point
                        else
                            RegFail = false;
                        end
                        
                    elseif strcmpi(lambda_method, 'quasi')
                        
                        [RegLambda,Q,reg_param]  = quasiopt(U1,sm1,pot1,reg_method);
                        
                        if RegLambda == reg_param(end)
                            RegFail = true; % The regularization parameter was set to the first point
                        else
                            RegFail = false;
                        end
                    elseif strcmpi(lambda_method, 'ncp')
                        
                        [RegLambda,G,reg_param]  = ncp(U1,sm1,pot1,reg_method);
                        
                        if RegLambda == reg_param(end)
                            RegFail = true; % The regularization parameter was set to the first point
                        else
                            RegFail = false;
                        end
                    end
                    close(hF)
                    RegLambda = repmat(RegLambda, 1, size(pot,2));
                    RegFail = repmat(RegFail, 1, size(pot,2));
                end
                
                C.RegLambda = RegLambda;
                C.RegFail = RegFail;
                C.RegFail = reshape(C.RegFail, [C.NumSamples C.NumTrials]);
                
            end
            
            BasisWeights = nan(size(C.F,2), size(pot,2));
            Rho = nan(1, size(pot,2));
            Eta = nan(1, size(pot,2));
            
            for i = 1:size(pot,2)
                if strcmpi(reg_method,'tikh')
                    [BasisWeights(:,i),Rho(i),Eta(i)] = tikhonov(U,sm,X,pot(:,i),RegLambda(i));
                elseif strcmpi(reg_method,'tsvd')
                    if H == 0
                        [BasisWeights(:,i),Rho(i),Eta(i)] = tsvd(U,sm,X,pot(:,i),RegLambda(i));
                    else
                        [BasisWeights(:,i),Rho(i),Eta(i)] = tgsvd(U,sm,X,pot(:,i),RegLambda(i));
                    end
                elseif strcmpi(reg_method,'dsvd')
                    [BasisWeights(:,i),Rho(i),Eta(i)] = dsvd(U,sm,X,pot(:,i),RegLambda(i));
                end
            end
            
            C.BasisWeights = BasisWeights;
            C.Rho = Rho;
            C.Eta = Eta;
            
            C.RegLambda = reshape(C.RegLambda, [C.NumSamples C.NumTrials]);
            C.Rho = reshape(C.Rho, [C.NumSamples C.NumTrials]);
            C.Eta = reshape(C.Eta, [C.NumSamples C.NumTrials]);
            
            C.BasisWeights = reshape(C.BasisWeights, [size(C.F,2) C.NumSamples C.NumTrials]);
            
        end
        
        function FindOptimalLambdaHansen(C)
            % This function searches for the best possible regularization
            % coefficient lambda given the known source function.
            
            C.FindIdealWeights;
            
            reg_method = C.RegularizationMethod{1};
            
            pot = reshape(C.Pot, [C.NumEl C.NumSamples*C.NumTrials]);
            
            if size(C.F,1) > C.NumEl % Add an imaginary zero potential at the top and bottom for the iCSD spline method
                pot = cat(1,zeros(1, size(pot,2)), pot, zeros(1, size(pot,2)));
            end
            
            OptimalBasisWeights = nan(size(C.F,2), size(pot,2));
            IdealBasisWeights = reshape(C.IdealBasisWeights,[size(C.F,2) C.NumSamples*C.NumTrials]);
            OptimalLambda = nan(size(pot,2),1);
            for i = 1:size(pot,2)
                
                if strcmpi(reg_method,'tikh') || strcmpi(reg_method,'dsvd')
                    weight_err = @(lambda) C.GetWeightMisfitNorm(IdealBasisWeights(:,i),C.GetWeights(lambda, pot(:,i), reg_method));
                    OptimalLambda(i) = fminbnd(weight_err, 0, 10, optimset('TolX',1e-12));
                elseif strcmpi(reg_method,'tsvd')
                    weight_err = @(lambda) C.GetWeightMisfitNorm(IdealBasisWeights(:,i),C.GetWeights(round(lambda), pot(:,i), reg_method));
                    OptimalLambda(i) = round(fminbnd(weight_err, 0, length(C.sm), optimset('TolX',1e-12)));
                end
                
                OptimalBasisWeights(:,i) = C.GetWeights(OptimalLambda(i), pot(:,i), reg_method);
                
            end
            C.OptimalLambda = OptimalLambda;
            C.OptimalBasisWeights = OptimalBasisWeights;
            C.OptimalBasisWeights = reshape(C.OptimalBasisWeights,[size(C.F,2) C.NumSamples C.NumTrials]);
            C.OptimalLambda = reshape(C.OptimalLambda,[C.NumSamples C.NumTrials]);
        end
        
        function GetOutliers(C,thresh)
            
            if nargin == 1
                thresh = 10;
            end
            
            C.RegOutlier = (C.RegLambda./C.OptimalLambda > thresh) | (C.RegLambda./C.OptimalLambda < 1/thresh) & ~C.RegFail;
            
        end
        
        function [Weights, Rho, Eta] = GetWeights(C, Lambda, Data, reg_method)
            
            if strcmpi(reg_method,'tikh')
                [Weights, Rho, Eta] = tikhonov(C.U,C.sm,C.X,Data,Lambda);
            elseif strcmpi(reg_method,'tsvd')
                if C.H == 0
                    [Weights, Rho, Eta] = tsvd(C.U,C.sm,C.X,Data,Lambda);
                else
                    [Weights, Rho, Eta] = tgsvd(C.U,C.sm,C.X,Data,Lambda);
                end
            elseif strcmpi(reg_method,'dsvd')
                [Weights, Rho, Eta] = dsvd(C.U,C.sm,C.X,Data,Lambda);
            end
            Weights = Weights(:);
            
        end
        
        function FindCrossValLambda(C, varargin)
            if nargin == 2
                trial_wise = true;
            else
                trial_wise = false;
            end
            n_folds = C.NumEl;
            if isempty(C.RegLambdaZero),
                C.RegLambdaZero = 10^8; % Maybe we should start at a high value (see Argument in Parker)
            end
            
            if isempty(C.RegNoiseEst)
                C.H = eye(size(C.F));
                C.RegNoiseEst = 1;
            elseif numel(C.RegNoiseEst) == 1
                C.H = C.RegNoiseEst.^2*eye(size(C.F));
            else % if 1 value is defined for each electrode
                if size(C.F,1)>length(C.RegNoiseEst)
                    C.H = diag([1 C.RegNoiseEst.^2 1],0);
                else
                    C.H = diag(C.RegNoiseEst.^2,0);
                end
            end
            
            pot = reshape(C.Pot, [C.NumEl C.NumSamples*C.NumTrials]);
            
            % Find Best Regularization Parameter through cross-validation
            if trial_wise
                C.RegLambda = nan(1, size(pot,2));
                for i = 1:size(pot,2)
                    CSDerr = @(lambdaReg) CSD2layer.CrossVal(abs(lambdaReg),C.F, pot(:,i),C.H, n_folds);
                    
                    %                     C.RegLambda(i) = abs(fminsearch(CSDerr,C.RegLambdaZero));
                    C.RegLambda(i) = fminbnd(CSDerr, 0, 1, optimset('TolX',1e-12));
                    if  C.RegLambda(i) < 1e-12
                        C.RegLambda(i) = 0;
                    end
                end
            else
                CSDerr = @(lambdaReg) CSD2layer.CrossVal(abs(lambdaReg),C.F, pot,C.H, n_folds);
                
                %                 C.RegLambda = abs(fminsearch(CSDerr,C.RegLambdaZero));
                C.RegLambda = fminbnd(CSDerr, 0, 1, optimset('TolX',1e-12));
                if  C.RegLambda < 1e-12
                    C.RegLambda = 0;
                end
            end
        end
        
        function FindIdealLambda(C, varargin)
            if nargin == 2
                trial_wise = true;
            else
                trial_wise = false;
            end
            
            if isempty(C.RegLambdaZero),
                C.RegLambdaZero = 10^8; % Start at a high value (see Argument in Parker)
            end
            
            if isempty(C.RegNoiseEst)
                C.H = eye(size(C.F));
                C.RegNoiseEst = 1;
            elseif numel(C.RegNoiseEst) == 1
                C.H = C.RegNoiseEst.^2*eye(size(C.F));
            else % if 1 value is defined for each electrode
                if size(C.F,1)>length(C.RegNoiseEst)
                    C.H = diag([1 C.RegNoiseEst.^2 1],0);
                else
                    C.H = diag(C.RegNoiseEst.^2,0);
                end
            end
            
            pot = reshape(C.Pot, [C.NumEl C.NumSamples*C.NumTrials]);
            if size(C.F,1) > size(pot,1) % For the iCSD spline method
                pot = cat(1, zeros(1, size(pot,2)), pot, zeros(1, size(pot,2)));
            end
            
            RealPot = C.SimPotObj.NoiseFreePot;
            RealPot = reshape(RealPot, [size(RealPot,1) C.NumSamples*C.NumTrials]);
            if ~isempty(C.BadChannels) && ~C.InterpPot
                RealPot = RealPot(setdiff(1:length(C.OriginalElPos), C.BadChannels),:);
            end
            
            % Find Best Regularization Parameter through comparison with
            % the true function
            
            if trial_wise
                C.RegLambda = nan(1, size(pot,2));
                for i = 1:size(pot,2)
                    CSDerr = @(lambdaReg) CSD2layer.GetIdealLambda(abs(lambdaReg),C.F, pot(:,i),C.H, RealPot(:,i));
                    
                    C.RegLambda(i) = fminbnd(CSDerr, 0, 1, optimset('TolX',1e-12));
                    if  C.RegLambda(i) < 1e-12
                        C.RegLambda(i) = 0;
                    end
                end
            else
                CSDerr = @(lambdaReg) CSD2layer.GetIdealLambda(abs(lambdaReg),C.F, pot,C.H, RealPot);
                
                C.RegLambda = fminbnd(CSDerr, 0, 1, optimset('TolX',1e-12));
                if  C.RegLambda < 1e-12
                    C.RegLambda = 0;
                end
            end
            
        end
        
    end
    
    methods (Access = protected)
        
        function ResetPotVars(C)
            if C.TextOutput
                fprintf('Reseting all variables that depend on the potential or the weights\n')
            end
            % Reset all the variables that depend on the potential or the
            % weights
            C.BasisWeights = [];
            
            C.DataMisfit; % ||F*m-d||
            
            C.IdealBasisWeights;
            
            C.IdealCSDest;
            
            C.OptimalLambda;
            
            C.OptimalBasisWeights = [];
            
            C.OptimalCSDest = [];
            
            C.OptimalEstErr = [];
            
            C.IdealEstErr = [];
            
            C.PotErr = [];
            
            C.H = [];
            
            C.CSDest = [];
            
            C.EstErr = [];
            
            C.RegLambda = [];
            
            C.RegFail = false(C.NumSamples, C.NumTrials);
            
            C.RegOutlier = false(C.NumSamples, C.NumTrials);
            
            C.ResMat = [];
            
            C.Filtered = false;
            
        end
        
        function ResetReadOutVars(C)
            if C.TextOutput
                fprintf('Reseting all variables that depend on the ReadOutRegion\n')
            end
            % Reset all the variables that depend on the ReadOutRegion
            
            C.ResetReadOutClassSpecific;
            
            C.OptimalCSDest = [];
            
            C.OptimalEstErr = [];
            
            C.IdealCSDest = [];
            
            C.IdealEstErr = [];
            
            C.CSDest = [];
            
            C.EstErr = [];
            
            C.ResMat = [];
            
            C.Filtered = false;
            
        end
        
    end
    
    methods (Static = true) % Forward Problem Function
        
        function pot = Pot1Layer(zs,ze,R,ExCond,ForwardFunc)
            
            pot =  1/ExCond*ForwardFunc(zs,ze,R);
            
        end
        
        function pot = Pot2Layer(zs,ze,R,TopCond,ExCond,ForwardFunc)
            
            L12 = (TopCond-ExCond)/(ExCond+TopCond);
            
            pot =  (1/ExCond*(ForwardFunc(zs,ze,R) - L12*ForwardFunc(-zs,ze,R)).*(zs >= 0) ...
                        + 2/(ExCond+TopCond)*ForwardFunc(zs,ze,R).*(zs < 0)).*(ze >= 0)...
                        ...
                        + (1/TopCond*(ForwardFunc(zs,ze,R) + L12*ForwardFunc(-zs,ze,R)).*(zs <= 0) ...
                        + 2/(ExCond+TopCond)*ForwardFunc(zs,ze,R).*(zs > 0)).*(ze < 0);
                    
        end
        
        function pot = Pot3LayerParallel(zS,zE,R, TopCond,ExCond, BottomCond,ForwardFunc, a, N)
            
            r = R;
            
            D = 2*a;
            L12 = (TopCond-ExCond)/(TopCond+ExCond);
            L32 = (BottomCond-ExCond)/(BottomCond+ExCond);
            
            % Source in Top layer
            Top_Top = @(zs,ze,r,n) -(2*TopCond/(TopCond+ExCond))*(2*ExCond/(TopCond+ExCond))*(L12*L32)^n*(L32.*ForwardFunc(-zs+2*D*n+D,ze,r));%./sqrt(r^2+(ze+zs-2*D*n-D).^2));
            Top_Mid = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs-2*D*n,ze,r) - L32.*ForwardFunc(-zs+2*D*n+D,ze,r));
            Top_Bottom = @(zs,ze,r,n) (L12*L32)^n*ForwardFunc(zs-2*D*n,ze,r);
            
            % Source in Mid layer
            Mid_Mid1 = @(zs,ze,r,n) (L12*L32)^n*(L12.*ForwardFunc(-zs-2*D*n-D,ze,r) + L32.*ForwardFunc(-zs+2*D*n+D,ze,r));
            Mid_Mid2 = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r) + ForwardFunc(zs-2*D*n,ze,r));
            Mid_Top = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r) - L32.*ForwardFunc(-zs+2*D*n+D,ze,r));
            Mid_Bottom = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs-2*D*n,ze,r) - L12.*ForwardFunc(-zs-2*D*n-D,ze,r));
            
            % Source in Bottom layer
            Bottom_Bottom = @(zs,ze,r,n) -(2*BottomCond/(BottomCond+ExCond))*(2*ExCond/(BottomCond+ExCond))*(L12*L32)^n*(L12.*ForwardFunc(-zs-2*D*n-D,ze,r));
            Bottom_Mid = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r) - L12.*ForwardFunc(-zs-2*D*n-D,ze,r));
            Bottom_Top = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r));
            
            
            
            pot = zeros(size(zS));
            ze = zE - a;
            zs = zS - a;
            for n = 0:N
                if n == 0
                    pot = pot + ...
                        (Bottom_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a) +  ...
                        Bottom_Bottom(zs,ze,r,n).*(ze > a)).*(zs > a) + ...
                        (Mid_Top(zs,ze,r, n).*(ze < -a) - ...
                        Mid_Mid1(zs,ze,r, n).*double(ze >= -a & ze <= a) + ...
                        Mid_Bottom(zs,ze,r, n).*(ze > a)).*double(zs >= -a & zs <= a) + ...
                        (Top_Top(zs,ze,r,n).*(ze < -a)+...
                        Top_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a)).*(zs < -a);
                else
                    pot = pot + ...
                        (Bottom_Top(zs,ze,r,n).*(ze < -a) +  ...
                        Bottom_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a) +  ...
                        Bottom_Bottom(zs,ze,r,n).*(ze > a)).*(zs > a) + ...
                        (Mid_Top(zs,ze,r, n).*(ze < -a) + ...
                        (Mid_Mid2(zs,ze,r, n) - Mid_Mid1(zs,ze,r, n)).*double(ze >= -a & ze <= a) + ...
                        Mid_Bottom(zs,ze,r, n).*(ze > a)).*double(zs >= -a & zs <= a) +...
                        (Top_Top(zs,ze,r,n).*(ze < -a)+...
                        Top_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a) + ...
                        Top_Bottom(zs,ze,r,n).*(ze > a)).*(zs < -a);
                    
                end
                
                if n == N
                    pot = ...
                        ((2/(TopCond+ExCond))*((2*ExCond)/(BottomCond+ExCond))*(ForwardFunc(zs,ze,r) + pot).*(ze < -a) +  ...
                        (2/(BottomCond+ExCond))*pot.*double(ze >= -a & ze <= a) + ...
                        (1/BottomCond)*(pot + ForwardFunc(zs,ze,r) + L32.*ForwardFunc(-zs+D,ze,r)).*(ze > a)).*(zs > a) + ...
                        ((2/(ExCond+TopCond))*pot.*(ze < -a) + ...
                        1/ExCond*(ForwardFunc(zs,ze,r) + pot).*double(ze >= -a & ze <= a) + ...
                        (2/(ExCond+BottomCond))*pot.*(ze > a)).*double(zs >= -a & zs <= a) + ...
                        ((1/TopCond)*(pot + ForwardFunc(zs,ze,r) + L12.*ForwardFunc(-zs-D,ze,r)).*(ze < -a) + ...
                        (2/(TopCond+ExCond))*pot.*double(ze >= -a & ze <= a) + ...
                        (2/(BottomCond+ExCond))*((2*ExCond)/(TopCond+ExCond))*(ForwardFunc(zs,ze,r) + pot).*(ze > a)).*(zs < -a);
                    
                end
                
                
            end

        end
        
    end
    
    methods (Static = true)
        
        function [reg_corner,rho,eta,reg_param, rho_c,eta_c] = L_curve_Hansen(U,sm,data,reg_method, Bound)
            
            if ~exist('Bound', 'var'), Bound = []; end
            
            npoints = 200;  % Number of points on the L-curve for Tikh and dsvd.
            smin_ratio = 16*eps;  % Smallest regularization parameter.
            
            method = reg_method;
            b = data;
            % Initialization.
            [m,n] = size(U); [p,ps] = size(sm);
            %             if (nargout > 0), locate = 1; else locate = 0; end
            
            beta = U'*b;
            beta2 = norm(b)^2 - norm(beta)^2;
            if (ps==1)
                s = sm; beta = beta(1:p,:);
            else
                s = sm(p:-1:1,1)./sm(p:-1:1,2); % gives the generalized singular values
                beta = beta(p:-1:1,:); % inverted because in gSVD the singular values (and also eigenvector) are arranged in decreasing order
            end
            xi = beta(1:p,:)./repmat(s,1,size(beta,2)); % xi = U'd/s
            
            if (strncmp(method,'Tikh',4) || strncmp(method,'tikh',4))
                
                eta = zeros(npoints,1); rho = eta; reg_param = eta; s2 = s.^2;
                reg_param(npoints) = max([s(p),s(1)*smin_ratio]);
                ratio = (s(1)/reg_param(npoints))^(1/(npoints-1));
                for i=npoints-1:-1:1
                    reg_param(i) = ratio*reg_param(i+1);
                end
                for i=1:npoints
                    
                    f = s2./(s2 + reg_param(i)^2);
%                     eta(i) = norm(repmat(f,1,size(beta,2)).*xi); 
%                     rho(i) = norm(repmat((1-f),1,size(beta,2)).*beta(1:p,:)); 
                    eta(i) = sum(sqrt(sum((repmat(f,1,size(beta,2)).*xi).^2,1)),2);% model norm
                    rho(i) = sum(sqrt(sum((repmat((1-f),1,size(beta,2)).*beta(1:p,:)).^2,1)),2);% misfit norm
                    
                end
                
                if (m > n && beta2 > 0), rho = sqrt(rho.^2 + beta2); end
                
            elseif (strncmp(method,'tsvd',4) || strncmp(method,'tgsv',4))
                
                eta = zeros(p,1); rho = eta;
                eta(1) = abs(xi(1))^2;
                for k=2:p, eta(k) = eta(k-1) + abs(xi(k))^2; end
                eta = sqrt(eta);
                if (m > n)
                    if (beta2 > 0), rho(p) = beta2; else rho(p) = eps^2; end
                else
                    rho(p) = eps^2;
                end
                for k=p-1:-1:1, rho(k) = rho(k+1) + abs(beta(k+1))^2; end
                rho = sqrt(rho);
                reg_param = (1:p)';% marker = 'o';
                if (ps==1)
                    U = U(:,1:p); %txt = 'TSVD';
                else
                    U = U(:,1:p); %txt = 'TGSVD';
                end
                
            elseif (strncmp(method,'dsvd',4) || strncmp(method,'dgsv',4))
                
                eta = zeros(npoints,1); rho = eta; reg_param = eta;
                reg_param(npoints) = max([s(p),s(1)*smin_ratio]);
                ratio = (s(1)/reg_param(npoints))^(1/(npoints-1));
                for i=npoints-1:-1:1, reg_param(i) = ratio*reg_param(i+1); end
                for i=1:npoints
                    f = s./(s + reg_param(i));
                    eta(i) = norm(f.*xi);
                    rho(i) = norm((1-f).*beta(1:p));
                end
                if (m > n & beta2 > 0), rho = sqrt(rho.^2 + beta2); end
                
            elseif (strncmp(method,'mtsv',4))
                
                if (nargin~=6)
                    error('The matrices L and V must also be specified')
                end
                [p,n] = size(L); rho = zeros(p,1); eta = rho;
                [Q,R] = qr(L*V(:,n:-1:n-p),0);
                for i=1:p
                    k = n-p+i;
                    Lxk = L*V(:,1:k)*xi(1:k);
                    zk = R(1:n-k,1:n-k)\(Q(:,1:n-k)'*Lxk); zk = zk(n-k:-1:1);
                    eta(i) = norm(Q(:,n-k+1:p)'*Lxk);
                    if (i < p)
                        rho(i) = norm(beta(k+1:n) + s(k+1:n).*zk);
                    else
                        rho(i) = eps;
                    end
                end
                if (m > n & beta2 > 0), rho = sqrt(rho.^2 + beta2); end
                reg_param = (n-p+1:n)'; txt = 'MTSVD';
                U = U(:,reg_param); sm = sm(reg_param);
                marker = 'x'; ps = 2;  % General form regularization.
                
            else
                error('Illegal method')
            end
            
            if isempty(Bound)
                [reg_corner,rho_c,eta_c] = l_corner(rho,eta,reg_param,U,sm,data,reg_method);
            else
                [reg_corner,rho_c,eta_c] = l_corner(rho,eta,reg_param,U,sm,data,reg_method, Bound);
            end
            
        end
        
        function [reg_min,G,reg_param] = GCV_Hansen(U,sm,data,reg_method)
            hF = figure('Visible','off');
            [reg_min,G,reg_param] = gcv(U,sm,data,reg_method);
            close(hF)
        end
        
        function Plot_L_curve(eta,rho,marker, ps,reg_param, color, rho_c,eta_c)
            
            marker = '-';
            np = 10;                           % Number of identified points.
            
            % Initialization.
            if (ps < 1 | ps > 2), error('Illegal value of ps'), end
            n = length(rho); ni = round(n/np);
            
            % Make plot.
            loglog(rho(2:end-1),eta(2:end-1),'color', color), ax = axis;
            if (max(eta)/min(eta) > 10 | max(rho)/min(rho) > 10)
                %                 if (nargin < 5)
                loglog(rho,eta,marker,'color', color), axis(ax)
                %                 else
                %                     loglog(rho,eta,marker,rho(ni:ni:n),eta(ni:ni:n),'x'), axis(ax)
                %                     HoldState = ishold; hold on;
                %                     for k = ni:ni:n
                %                         text(rho(k),eta(k),num2str(reg_param(k)));
                %                     end
                %                     if (~HoldState), hold off; end
                %                 end
                axis('tight')
                ax = axis;
                hold on;
                loglog([min(rho)/100,rho_c],[eta_c,eta_c],':r',...
                    [rho_c,rho_c],[min(eta)/100,eta_c],':r')
                %                 title(['L-curve, ',txt,' corner at ',num2str(reg_corner)]);
                %                 xlim([rho(end) rho(1)]);%ylim([eta(1) eta(end)]);
                axis(ax)
                %
                hold off
            else
                %                 if (nargin < 5)
                plot(rho,eta,marker,'color', color), axis(ax)
                %                 else
                %                     plot(rho,eta,marker,rho(ni:ni:n),eta(ni:ni:n),'x','color', color), axis(ax)
                %                     HoldState = ishold; hold on;
                %                     for k = ni:ni:n
                %                         text(rho(k),eta(k),num2str(reg_param(k)));
                %                     end
                %                     if (~HoldState), hold off; end
                %                 end
            end
            xlabel('residual norm || A x - b ||_2')
            if (ps==1)
                ylabel('solution norm || x ||_2')
            else
                ylabel('solution semi-norm || L x ||_2')
            end
            title('L-curve')
        end
        
        function Plot_GCV(reg_min, G,reg_param, method, color)
            if (strncmp(method,'Tikh',4) || strncmp(method,'tikh',4))
                % Plot GCV function.
                loglog(reg_param,G,'color',color), xlabel('\lambda'), ylabel('G(\lambda)')
                ax = axis;
                hold on;
                addline(reg_min,'v','color',color);
                title(['GCV function, minimum at \lambda = ',num2str(reg_min)])
                axis(ax)
                xlim([reg_param(end) reg_param(1)]);
                hold off
                
                
            elseif (strncmp(method,'tsvd',4) | strncmp(method,'tgsv',4))
                
                % Plot GCV function.
                semilogy(reg_param,G,'o', 'color', color), xlabel('k'), ylabel('G(k)')
                
                ax = axis;
                hold on;
                addline(reg_min,'v','color',color);title(['GCV function, minimum at k = ',num2str(reg_min)])
                axis(ax);
                hold off;
                
                
            elseif (strncmp(method,'dsvd',4) | strncmp(method,'dgsv',4))
                
                
                % Plot GCV function.
                loglog(reg_param,G,':', 'color', color), xlabel('\lambda'), ylabel('G(\lambda)')
                
                ax = axis;
                hold on;
                addline(reg_min,'v','color',color);title(['GCV function, minimum at \lambda = ',num2str(reg_min)])
                axis(ax)
                hold off;
                
                
            elseif (strncmp(method,'mtsv',4) | strncmp(method,'ttls',4))
                
                error('The MTSVD and TTLS methods are not supported');
                
            end
        end
        
        function Plot_NCP(reg_min,dist,reg_param,method,color)
            npoints = 200;                      % Number of initial NCPS for Tikhonov.
            nNCPs = 20; 
            
            % tikh
            stp = round(npoints/nNCPs);
            plot(cp(:,1:stp:npoints)), hold on
            
            % Find minimum.
            [minG,minGi] = min(dists); % Initial guess.
            reg_min = fminbnd('ncpfun',...
                reg_param(min(minGi+1,npoints)),reg_param(max(minGi-1,1)),...
                optimset('Display','off'),s,beta(1:p),U(:,1:p)); % Minimizer.
            [dist,cp] = ncpfun(reg_min,s,beta(1:p),U(:,1:p));
            plot(cp,'-r','linewidth',3), hold off
            title(['Selected NCPs.  Most white for \lambda = ',num2str(reg_min)])
            
            % tsvd, tgsvd
            plot(cp), hold on
            plot(1:q,cp(:,reg_min),'-r','linewidth',3), hold off
            title(['Most white for k = ',num2str(reg_min)])
  
            % dsvd
            stp = round(npoints/nNCPs);
            plot(cp(:,1:stp:npoints)), hold on
            
            % Find minimum, if requested.
            [minG,minGi] = min(dists); % Initial guess.
            reg_min = fminbnd('ncpfun',...
                reg_param(min(minGi+1,npoints)),reg_param(max(minGi-1,1)),...
                optimset('Display','off'),s,beta(1:p),U(:,1:p),1); % Minimizer.
            [dist,cp] = ncpfun(reg_min,s,beta(1:p),U(:,1:p));
            plot(cp,'-r','linewidth',3), hold off
            title(['Selected NCPs.  Most white for \lambda = ',num2str(reg_min)])
  
        end
        
    end
    
    methods % Get methods
        
        function ElectrodeIdx = get.ElectrodeIdx(C)
            if isempty(C.ReadOutRegion)
                ElectrodeIdx = [];
            else
                ElectrodeIdx = nan(C.NumEl,1);
                for i = 1:C.NumEl
                    idx = find(round(C.ElectrodePositions(i)*10^6) == round(C.ReadOutRegion*10^6),1);
                    if ~isempty(idx)
                        ElectrodeIdx(i) = idx;
                    end
                end
            end
        end
        
        function LastElOut = get.LastElOut(C)
            LastElOut = find(C.ElectrodePositions < 0,1 ,'last');
            if isempty(LastElOut)
                LastElOut = 0;
            end
        end
        
        function LastOutReadOut = get.LastOutReadOut(C)
            LastOutReadOut = find(C.ReadOutRegion < 0,1 ,'last');
            if isempty(LastOutReadOut)
                LastOutReadOut = 0;
            end
        end
        
        function ReadOutSampling = get.ReadOutSampling(C)
            ReadOutSampling = median(diff(C.ReadOutRegion));
        end
        
        function RegularSpacedReadOut = get.RegularSpacedReadOut(C)
            RegularSpacedReadOut = length(unique(round(diff(C.ReadOutRegion)*10^6)/10^6)) == 1;
        end
        
        function NumEl = get.NumEl(C)
            NumEl = length(C.ElectrodePositions);
        end
        
        function NumSamples = get.NumSamples(C)
            NumSamples = size(C.Pot,2);
        end
        
        function NumTrials = get.NumTrials(C)
            NumTrials = size(C.Pot,3);
        end
        
        function NumReadOut = get.NumReadOut(C)
            NumReadOut = length(C.ReadOutRegion);
        end
        
        function R = get.R(C)
            R = C.Diameter/2;
        end
        
    end
    
    methods (Static = true)% Cross-Validation Regularization Methods copied from kCSD
        
        function err = GetIdealLambda(lambda,F, pot, H, RealPot)
            % Still need to think about how to include H in the picture
            % How to choose H for uneven sampling (also applies to the problem with bad
            % channels)
            
            alpha = (F + abs(lambda).*H)\pot;
            Pot_est = F*alpha;
            
            if size(RealPot,1) < size(F,1) % spline case
                err = norm(RealPot - Pot_est(2:end-1,:));
            else
                err = norm(RealPot - Pot_est);
            end
            
        end % Written by Pascal
        
        function err = CrossVal(lambda,F, pot, H, n_folds)
            % Still need to think about how to include H in the picture
            % How to choose H for uneven sampling (also applies to the problem with bad
            % channels)
            Ind_perm = randperm(size(pot,1));
            err = CSD2layer.cross_validation(lambda, F, pot, H, n_folds, Ind_perm);
            
        end
        
        function err = cross_validation(lambda, F, pot, H, n_folds, Ind_perm)
            % K - fold cross validati
            % preparing subsets of electrodes
            
            [n, ~] = size(pot);
            width = floor(n/n_folds);
            Ind = cell(n_folds);
            All_ind = 1:1:n;
            
            for i = 1 : n_folds
                Ind_set = (1:1:width) + width*(i-1);
                Ind_set_perm = Ind_perm(Ind_set);
                Ind{i} = Ind_set_perm;
            end;
            
            last = max(Ind_set);
            
            if last < n
                Ind{n_folds} = [Ind{n_folds} Ind_perm(last+1:1:n)];
            end;
            
            errors = zeros(n_folds, 1);
            
            for i = 1:n_folds
                Ind_test = Ind{i};
                Ind_train = All_ind;
                Ind_train(Ind{i}) =[];
                errors(i) = CSD2layer.calc_err(lambda, F, pot, H, Ind_test, Ind_train);
            end;
            
            err = mean(errors);
        end
        
        function err = calc_err(lambda,  F, pot, H, Ind_test, Ind_train)
            
            if size(F,1) > size(pot,1) % For the spline method
                Ind_test = Ind_test+1;
                Ind_train = Ind_train+1;
                pot = cat(1, zeros(1, size(pot,2)), pot, zeros(1, size(pot,2)));
            end
            F_train = F(Ind_train, Ind_train);
            
            Pot_train = pot(Ind_train,:);
            
            Pot_test = pot(Ind_test,:);
            
            H_train = H(Ind_train, Ind_train);
            
            alpha = (F_train + abs(lambda).*H_train)\Pot_train;
            
            F_cross = F(Ind_test, Ind_train);
            
            Pot_est = F_cross*alpha;
            
            
            %% ?? Unsure what is happening here
            
            % Pot_est = zeros(size(Ind_test'));
            % for i = 1:length(CSD)
            %     Pot_est = Pot_est + CSD(i) .* F_cross(:, i);
            % end
            
            err = norm(Pot_test - Pot_est);
        end
        
    end
    
end