classdef SimPot2layer < handle
    properties % Simulated Data Properties
        
        ElectrodePositions; % in mm, without jitter
        
        RealCSD; % function handle of the CSD as a function of depth
        
        NoiseFreePot; % Potential without noise (in mV)
        
        Noise; % only the noise (in mV)
        
        SourceParameters; % Other information used for defining the source (e.g. start position)
        
        SourceInt; % Intensity of the Source in uA/mm^3
        
        RealSourceShape; % either 'unicyl' or 'gaussian'
        
        RealDiameter; % in mm
        
        RealNumLayers; % number of layers in forward model (either 1, 2, or 3)
        
        RealTopCond; % in S/m
        
        RealExCond; % in S/m
        
        RealBottomCond; % in S/m
        
        WhiteMatterDepth = []; % in mm
        
        N = 20; % Number of image source levels in calculating three-layered medium
        
        RealJitter; % Jitter in the location of the boundary - in mm
        
        SNRdB; % Signal to noise ratio in dB - 10*log10(SNRlin)
        
        SNRlin; % SNRlin = mean(noiselesspot^2)/mean(noise^2) - 10^(SNRdB/10)
        
        NoiseAmp; % Noise Amplitude such that SNRlin = mean(noiselesspot^2)/mean(NoiseAmp^2)
        
        SignalPower; % Calculated as the square of the values - mean(sig.^2)
        
        SignalVar; % Variance of the Signal
        
        NoisePower;
        
        NoiseVar; % Variance of the Noise
        
        NoiseType; % 'normal', 'uniform'
        
        OffCenter; % in mm;  0 = the electrode is centered
        
        PotFun; % handle to function of the data representers (only for offset = 0)
        
        TextOutput; 
        
    end
    
    properties (Dependent = true)
        
        NumEl;
        
        Pot;
        
    end
    
    methods
        
        function C = SimPot2layer(ElectrodePositions, TextOutput, Params) % class constructor
            
            C.ElectrodePositions = ElectrodePositions;
            
            C.TextOutput = TextOutput;
            
            %% Input
            % Params (structure)
            % Fields to be defined:
            %   SourceFunc: CSD intensity as a function of depth. Can
            %   either be a function handle for a function of depth. It is also possible
            %   to define the integration boundaries in the field IntBounds.
            %   Else the sine and sum of Gaussians example from Pettersen is included.
            %   To use the gaussian one needs to define the fields:
            %       - mu1, sigma1, mu2, sigma2
            %   To use the sine one needs to define the fields:
            %       - zstart, lambda
            %   - default sine with zstart = 0.1 and lambda = 1.
            %   SourceShape: either 'Uniform' or 'Gaussian': default 'Uniform'
            %   NumLayers: either 1, 2, or 3
            %   TopCond: Conductivity for top medium - in S/m: default 1.7
            %   ExCond: Conductivity for extracellular medium - in S/m:
            %   default 0.3
            %   BottomCond: Conductivity for Bottom medium - in S/m:
            %   default 0.1
            %   WhiteMatterDepth: At which depth does the White Matter
            %   start - in mm (0 = transition from Top to Extracellular
            %   medium
            %   N: Number of image source levels in calculating
            %   three-layered medium: default 20
            %   Diameter: Diameter of sources to use for generating the
            %   potential - in mm: default 0.5 mm
            %   Jitter: Constant shift to be added to the electrode
            %   positions to simulate errors in placement - in mm: default 0
            %   SNRdB or SNRlin: SNR for the white Gaussian Noise to be
            %   added - Leave empty if no noise is to be added: default []
            %   SourceInt - Intesity of the source. This can be a scalar, a
            %   vector or a matrix indexed as intensity of samples * intensity
            %   over trials - in ua/mm^3: default 1
            %   NumSamples - How many samples should be created. This will
            %   be overridden if SourceInt is a row vector or a matrix: default 1
            %   NumTrials - How many trials should be created. This will
            %   be overridden if SourceInt is a column vector or a matrix: default 1
            %   OffCenter: Is the electrode centered on the gaussian or the
            %   cylinder - in mm: default = 0;
            
            if isfield(Params, 'NoiseType') && ~isempty(Params.NoiseType)
                C.NoiseType = Params.NoiseType;
            else
                C.NoiseType = 'normal';
            end
            
            if isfield(Params, 'NoiseAmp') && ~isempty(Params.NoiseAmp)
                if C.TextOutput
                    disp(['Noise (' C.NoiseType ') is added to simulated potential']);
                end
                C.NoiseAmp = Params.NoiseAmp;
                C.SNRdB = []; % Just to avoid confusion
                C.SNRlin = []; % Just to avoid confusion
                
            elseif isfield(Params, 'SNRdB') && ~isempty(Params.SNRdB)
                if C.TextOutput
                    disp(['Noise (' C.NoiseType ') is added to simulated potential']);
                end
                C.SNRdB = Params.SNRdB;
                C.SNRlin = []; % Just to avoid confusion
                C.NoiseAmp = []; % Just to avoid confusion
                
            elseif isfield(Params, 'SNRlin') && ~isempty(Params.SNRlin)
                if C.TextOutput
                    disp(['Noise (' C.NoiseType ') is added to simulated potential']);
                end
                C.SNRlin = Params.SNRlin;
                C.SNRdB = []; % Just to avoid confusion
                C.NoiseAmp = []; % Just to avoid confusion
                
            else
                if C.TextOutput
                    disp('No noise is added to simulated potential');
                end
                C.SNRdB = []; % Just to avoid confusion
                C.SNRlin = []; % Just to avoid confusion
                C.NoiseAmp = []; % Just to avoid confusion
                C.NoiseType = 'none';
            end
            
            if isfield(Params, 'SourceShape'), C.RealSourceShape = Params.SourceShape; else C.RealSourceShape = 'Uniform'; end
            if isfield(Params, 'NumLayers'), C.RealNumLayers = Params.NumLayers; else C.RealNumLayers = 1; end
            if isfield(Params, 'Diameter'), C.RealDiameter = Params.Diameter; else C.RealDiameter = 0.5; end
            if isfield(Params, 'Jitter'), C.RealJitter = Params.Jitter; else C.RealJitter = 0; end
            if isfield(Params, 'TopCond'), C.RealTopCond = Params.TopCond; else C.RealTopCond = 1.7; end
            if isfield(Params, 'ExCond'), C.RealExCond = Params.ExCond; else C.RealExCond = 0.3; end
            if isfield(Params, 'BottomCond'), C.RealBottomCond = Params.BottomCond; else C.RealBottomCond = []; end
            if isfield(Params, 'N') && ~isempty(Params.N), C.N = Params.N; else C.N = 20; end
            if isfield(Params, 'SourceInt'), C.SourceInt = Params.SourceInt; else C.SourceInt = 1; end
            if isfield(Params, 'OffCenter'), C.OffCenter = Params.OffCenter; else C.OffCenter = 0; end
            if C.RealNumLayers == 3
                if isfield(Params, 'WhiteMatterDepth'),
                    C.WhiteMatterDepth = Params.WhiteMatterDepth;
                else
                    error('3 layered forward model cannot be used without specifying WhiteMatterDepth');
                end
            end
            
            if size(C.SourceInt,2) > 1 % Intensity specified for more than 1 trial
                NumTrials = size(C.SourceInt,2);
            else
                if isfield(Params, 'NumTrials')
                    NumTrials = Params.NumTrials;
                    C.SourceInt = repmat(C.SourceInt,1,NumTrials);
                else
                    NumTrials = 1; % Default
                end
            end
            
            if size(C.SourceInt,1) > 1 % Intensity specified for more than 1 sample
                NumSamples = size(C.SourceInt,1);
            else
                if isfield(Params, 'NumSamples')
                    NumSamples = Params.NumSamples;
                    C.SourceInt = repmat(C.SourceInt, NumSamples,1);
                else
                    NumSamples = 1; % Default
                end
            end
            
            if ~isfield(Params, 'SourceFunc') % Define default
                Params.SourceFunc = 'sine';
                Params.zstart = 0.1;
                Params.lambda = 1;
                Params.zend = 1.1;
            end
            fields = {'SourceInt', 'SNRdB', 'SNRlin', 'NoiseAmp', 'SourceShape', 'TopCond', 'ExCond','BottomCond',...
                'WhiteMatterDepth', 'Diameter', 'Jitter'};
            
            C.SourceParameters = rmfield(Params, fields(isfield(Params,fields)));
            
            C.SimulatePotential(NumSamples, NumTrials);
            
        end
        
        function SimulatePotential(C, NumSamples, NumTrials)
            
            %% Numerical Integration
            R = C.RealDiameter/2; % in mm
            
            [C.RealCSD, IntBounds] = SimPot2layer.GetRealCSD(C.SourceParameters);
            
            if C.OffCenter == 0
                switch lower(C.RealSourceShape)    
                    case 'unicyl'
                        ForwardF = @(zs,ze,R) 1/2*(sqrt(R^2+(ze-zs).^2) - abs(ze-zs));
                    case 'gaussian'
                        ForwardF = @(zs,ze,R) 1/2*(sqrt(2*pi)*R/2).*erfcx(abs(ze-zs)/(sqrt(2)*R));
                    case 'point'
                        ForwardF = @(zs,ze,R) 1/(4*pi)*(1./sqrt(R^2+(ze-zs).^2));
                end
                
                switch C.RealNumLayers
                    case 1
                        fun = @(zs,ze,R) SimPot2layer.Pot1Layer(zs,ze,R,C.RealExCond,ForwardF);
                    case 2
                        fun = @(zs,ze,R) SimPot2layer.Pot2Layer(zs,ze,R,C.RealTopCond,C.RealExCond,ForwardF);
                    case 3
                        a = C.WhiteMatterDepth/2;
                        fun = @(zs,ze,R) SimPot2layer.Pot3LayerParallel(zs,ze,R, C.RealTopCond,C.RealExCond, C.RealBottomCond,ForwardF, a, C.N);
                end
                
                fun2 = @(zs,ze) C.RealCSD(zs).*fun(zs,ze,R);
                
                C.PotFun = fun2;
            end
            
            pot = nan(C.NumEl,1);
            for i = 1:C.NumEl
                if C.OffCenter == 0
                    
                    fun3 = @(zs) fun2(zs,  C.ElectrodePositions(i)+C.RealJitter);
                    pot(i) = quadgk(fun3, IntBounds(1), IntBounds(2)); % in mV
                    
                else % Offcenter with 3 layers not implemented yet
                    
                    [pot(i)] = SimPot2layer.OffCenterFixedR(C.RealSourceShape,...
                        C.ElectrodePositions(i)+C.RealJitter, R, C.RealExCond,...
                        C.RealTopCond, C.RealCSD, IntBounds, C.OffCenter); % in mV
                    
                end
            end
            % Replicate the potential for the required # of samples and
            % trials and scale it by the source intensity. This is valid
            % because of the linearity of the potential generation.
            pot = repmat(reshape(C.SourceInt,[1 size(C.SourceInt)]),[C.NumEl,1,1]).*repmat(pot,[1 NumSamples NumTrials]);
            
            C.NoiseFreePot = pot;
            
            %% Add noise if desired
            % Mean of the overall signal power
            C.SignalPower = mean(pot.^2,1); % THIS DOESN'T WORK IF DIFFERENT INTENSITIES ARE USED
            
            C.SignalVar = var(pot,1,1);
            
            if isempty(C.SNRdB) && isempty(C.SNRlin) && isempty(C.NoiseAmp)
                C.SNRdB = inf;
                C.SNRlin = inf;
                
                C.NoisePower = 0;
                C.NoiseVar = 0;
                
                C.Noise = zeros(size(pot));
                
            else
                if ~isempty(C.NoiseAmp) % Noise Amplitude is directly specified
                    noisePower = repmat(C.NoiseAmp^2, size(C.SignalPower)); % desired noise power
                    C.SNRlin = C.SignalPower./noisePower; 
                    C.SNRdB = 10*log10(C.SNRlin);
                elseif ~isempty(C.SNRdB) % SNR was specified in dB
                    C.SNRlin = 10^(C.SNRdB/10);
                    noisePower = C.SignalPower/C.SNRlin; % desired noise power
                    C.NoiseAmp = sqrt(noisePower);
                else
                    C.SNRdB = 10*log10(C.SNRlin);
                    noisePower = C.SignalPower/C.SNRlin; % desired noise power
                    C.NoiseAmp = sqrt(noisePower);
                end
                
                
                switch C.NoiseType
                    case 'normal'
                        noise = repmat(sqrt(noisePower), [C.NumEl 1 1]).*randn(size(pot));
                        
                    case 'uniform'
                        noise = repmat(sqrt(noisePower), [C.NumEl 1 1]).*sqrt(3).*(2.*rand(size(pot))-1);
                        
                end
                
                C.NoisePower = mean(noise.^2,1); % measured noise power
                
                C.NoiseVar = var(noise,1,1);
                
                C.Noise = noise;
                
            end
        end
        
    end
    
    methods (Static = true) % CSD depth profiles
        
        function [RealCSD, IntBounds] = GetRealCSD(params)
            %% Define Source as a function of depth
            if isa(params.SourceFunc, 'function_handle')
                RealCSD = params.SourceFunc;
                if isfield(params, 'IntBounds'), 
                    IntBounds = params.IntBounds;
                else
                    IntBounds = [-inf, inf];
                end
            else
                switch lower(params.SourceFunc)
                    case 'sine'
                        RealCSD = @(z) sin(2*pi*(z-params.zstart)/params.lambda).*(z>=params.zstart & z<= params.zend);
                        IntBounds = [params.zstart params.zend];
                    case 'gauss'
                        if ~isfield(params, 'amp1'), params.amp1 = 1; end
                        if ~isfield(params, 'amp2'), params.amp2 = 1; end
                        
                        RealCSD = @(z) (params.amp1*exp(-(z - params.mu1).^2./(2*params.sigma1^2))- params.amp2*exp(-(z - params.mu2).^2/(2*params.sigma2^2))./(sqrt(2*pi))).*double(z>0);
                        IntBounds = [0 inf];
                        
                   case 'point'
                        RealCSD = @(z) double(z == params.sourceloc);
                        SourceLoc = params.sourceloc;
                        sourceshape = 'point';
                        
                    case 'glabska'
                        [RealCSD, IntBounds] = SimPot2layer.Glabska();
                        
                    case 'mono'
                        RealCSD = @(z) (params.amp1*exp(-(z - params.mu1).^2./(2*params.sigma1^2))).*double(z>0);
                        IntBounds = [0 params.mu1+5*params.sigma1];
                    
                    case 'dipole'
                        RealCSD = @(z) (params.amp1*exp(-(z - params.mu1).^2./(2*params.sigma1^2)) ...
                            - params.amp2*exp(-(z - params.mu2).^2/(2*params.sigma2^2))).*double(z>0);
                        IntBounds = [0 inf];
                        
                    case 'quad'
                        
                        RealCSD = @(z) (params.amp1*exp(-(z - params.mu1).^2./(2*params.sigma1^2)) ...
                            - params.amp2*exp(-(z - params.mu2).^2/(2*params.sigma2^2)) ...
                            + params.amp3*exp(-(z - params.mu3).^2/(2*params.sigma3^2))).*double(z>0);
                        
                        IntBounds = [0 inf];
                end
            end
        end
        
        function [fun, IntBounds] = Glabska()
            p0 = nan(3*6,1);
            p0(1) = 0.175;
            p0(2) = 0.145;
            p0(3) = 5.925;
            
            p0(1+3) = 0.812;
            p0(2+3) = 0.281;
            p0(3+3) = -14.202;
            
            p0(1+2*3) = 1.142;
            p0(2+2*3) = 0.111;
            p0(3+2*3) = 9.637;
            
            p0(1+3*3) = 1.680;
            p0(2+3*3) = 0.104;
            p0(3+3*3) = -7.89;
            
            p0(1+4*3) = 0.84;
            p0(2+4*3) = 0.148;
            p0(3+4*3) = 13.283;
            
            p0(1+5*3) = 1.305;
            p0(2+5*3) = 0.216;
            p0(3+5*3) = 6.356;
            
            p0(1+6*3) = 0.021;
            p0(2+6*3) = 0.062;
            p0(3+6*3) = -2.81;
            
            RealCSDp2 = @(z,p) (p(3)*exp(-(z - p(1)).^2./(2*p(2)^2))...
                + p(3+3)*exp(-(z - p(1+3)).^2./(2*p(2+3)^2))...
                + p(3+2*3)*exp(-(z - p(1+2*3)).^2./(2*p(2+2*3)^2))...
                + p(3+3*3)*exp(-(z - p(1+3*3)).^2./(2*p(2+3*3)^2))...
                + p(3+4*3)*exp(-(z - p(1+4*3)).^2./(2*p(2+4*3)^2))...
                + p(3+5*3)*exp(-(z - p(1+5*3)).^2./(2*p(2+5*3)^2))...
                + p(3+6*3)*exp(-(z - p(1+6*3)).^2./(2*p(2+6*3)^2))).*(z > 0 & z <= 2.045);
            
            fun = @(z) RealCSDp2(z,p0)/max(abs(RealCSDp2(0:0.001:2,p0)));
            IntBounds = [0 2.045];
        end
        
    end
    
    methods (Static = true) % Potential simulation
        
        function pot = Pot1Layer(zs,ze,R,ExCond,ForwardFunc)
            
            pot =  1/ExCond*ForwardFunc(zs,ze,R);
            
        end
        
        function pot = Pot2Layer(zs,ze,R,TopCond,ExCond,ForwardFunc)
            
            L12 = (TopCond-ExCond)/(ExCond+TopCond);
            
            pot =  (1/ExCond*(ForwardFunc(zs,ze,R) - L12*ForwardFunc(-zs,ze,R)).*(zs >= 0) ...
                        + 2/(ExCond+TopCond)*ForwardFunc(zs,ze,R).*(zs < 0)).*(ze >= 0)...
                        ...
                        + (1/TopCond*(ForwardFunc(zs,ze,R) + L12*ForwardFunc(-zs,ze,R)).*(zs <= 0) ...
                        + 2/(ExCond+TopCond)*ForwardFunc(zs,ze,R).*(zs > 0)).*(ze < 0);
                    
        end
        
        function pot = Pot3LayerParallel(zS,zE,R, TopCond,ExCond, BottomCond,ForwardFunc, a, N)
            
            r = R;
            
            D = 2*a;
            L12 = (TopCond-ExCond)/(TopCond+ExCond);
            L32 = (BottomCond-ExCond)/(BottomCond+ExCond);
            
            % Source in Top layer
            Top_Top = @(zs,ze,r,n) -(2*TopCond/(TopCond+ExCond))*(2*ExCond/(TopCond+ExCond))*(L12*L32)^n*(L32.*ForwardFunc(-zs+2*D*n+D,ze,r));
            Top_Mid = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs-2*D*n,ze,r) - L32.*ForwardFunc(-zs+2*D*n+D,ze,r));
            Top_Bottom = @(zs,ze,r,n) (L12*L32)^n*ForwardFunc(zs-2*D*n,ze,r);
            
            % Source in Mid layer
            Mid_Mid1 = @(zs,ze,r,n) (L12*L32)^n*(L12.*ForwardFunc(-zs-2*D*n-D,ze,r) + L32.*ForwardFunc(-zs+2*D*n+D,ze,r));
            Mid_Mid2 = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r) + ForwardFunc(zs-2*D*n,ze,r));
            Mid_Top = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r) - L32.*ForwardFunc(-zs+2*D*n+D,ze,r));
            Mid_Bottom = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs-2*D*n,ze,r) - L12.*ForwardFunc(-zs-2*D*n-D,ze,r));
            
            % Source in Bottom layer
            Bottom_Bottom = @(zs,ze,r,n) -(2*BottomCond/(BottomCond+ExCond))*(2*ExCond/(BottomCond+ExCond))*(L12*L32)^n*(L12.*ForwardFunc(-zs-2*D*n-D,ze,r));
            Bottom_Mid = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r) - L12.*ForwardFunc(-zs-2*D*n-D,ze,r));
            Bottom_Top = @(zs,ze,r,n) (L12*L32)^n*(ForwardFunc(zs+2*D*n,ze,r));
            
            
            
            pot = zeros(size(zS));
            ze = zE - a;
            zs = zS - a;
            for n = 0:N
                if n == 0
                    pot = pot + ...
                        (Bottom_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a) +  ...
                        Bottom_Bottom(zs,ze,r,n).*(ze > a)).*(zs > a) + ...
                        (Mid_Top(zs,ze,r, n).*(ze < -a) - ...
                        Mid_Mid1(zs,ze,r, n).*double(ze >= -a & ze <= a) + ...
                        Mid_Bottom(zs,ze,r, n).*(ze > a)).*double(zs >= -a & zs <= a) + ...
                        (Top_Top(zs,ze,r,n).*(ze < -a)+...
                        Top_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a)).*(zs < -a);
                else
                    pot = pot + ...
                        (Bottom_Top(zs,ze,r,n).*(ze < -a) +  ...
                        Bottom_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a) +  ...
                        Bottom_Bottom(zs,ze,r,n).*(ze > a)).*(zs > a) + ...
                        (Mid_Top(zs,ze,r, n).*(ze < -a) + ...
                        (Mid_Mid2(zs,ze,r, n) - Mid_Mid1(zs,ze,r, n)).*double(ze >= -a & ze <= a) + ...
                        Mid_Bottom(zs,ze,r, n).*(ze > a)).*double(zs >= -a & zs <= a) +...
                        (Top_Top(zs,ze,r,n).*(ze < -a)+...
                        Top_Mid(zs,ze,r,n).*double(ze >= -a & ze <= a) + ...
                        Top_Bottom(zs,ze,r,n).*(ze > a)).*(zs < -a);
                    
                end
                
                if n == N
                    pot = ...
                        ((2/(TopCond+ExCond))*((2*ExCond)/(BottomCond+ExCond))*(ForwardFunc(zs,ze,r) + pot).*(ze < -a) +  ...
                        (2/(BottomCond+ExCond))*pot.*double(ze >= -a & ze <= a) + ...
                        (1/BottomCond)*(pot + ForwardFunc(zs,ze,r) + L32.*ForwardFunc(-zs+D,ze,r)).*(ze > a)).*(zs > a) + ...
                        ((2/(ExCond+TopCond))*pot.*(ze < -a) + ...
                        1/ExCond*(ForwardFunc(zs,ze,r) + pot).*double(ze >= -a & ze <= a) + ...
                        (2/(ExCond+BottomCond))*pot.*(ze > a)).*double(zs >= -a & zs <= a) + ...
                        ((1/TopCond)*(pot + ForwardFunc(zs,ze,r) + L12.*ForwardFunc(-zs-D,ze,r)).*(ze < -a) + ...
                        (2/(TopCond+ExCond))*pot.*double(ze >= -a & ze <= a) + ...
                        (2/(BottomCond+ExCond))*((2*ExCond)/(TopCond+ExCond))*(ForwardFunc(zs,ze,r) + pot).*(ze > a)).*(zs < -a);
                    
                end
                
                
            end

        end
        
        function [pot, RealCSD] = OffCenterFixedR(sourceshape, ze, R, exCond, topCond, RealCSD, IntBounds, offcenter)
            
            %% Define Forward Model
            switch lower(sourceshape)
                case 'unicyl'

                        fun = @(z,r, phi) RealCSD(z)./(2*pi).*(...
                            ((1/(2*exCond)*(r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2) + ...
                            (exCond-topCond)/(exCond + topCond).*(r./sqrt((r.*cos(phi) - offcenter).^2 + (r.*sin(phi)).^2 + (z + ze).^2))).*(z>=0)) + ...
                            (1/(exCond + topCond)*(r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2)).*(z<0))).*(ze>=0)+...
                            ((1/(2*topCond)*(r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2) + ...
                            (topCond-exCond)/(exCond + topCond).*(r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z + ze).^2))).*(z<=0)) + ...
                            (1/(exCond + topCond)*(r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2)).*(z>0))).*(ze<0));
                     
                     IntBoundsR = [0, R];   
                     
                case 'gaussian'
                    
                     fun = @(z,r, phi) RealCSD(z)./(2*pi).*(...
                            ((1/(2*exCond)*(exp(-r.^2./(2*R^2)).*r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2) + ...
                            (exCond-topCond)/(exCond + topCond).*(exp(-r.^2./(2*R^2)).*r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z + ze).^2))).*(z>=0)) + ...
                            (1/(exCond + topCond)*(exp(-r.^2./(2*R^2)).*r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2)).*(z<0))).*(ze>=0)+...
                            ((1/(2*topCond)*(exp(-r.^2./(2*R^2)).*r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2) + ...
                            (topCond-exCond)/(exCond + topCond).*(exp(-r.^2./(2*R^2)).*r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z + ze).^2))).*(z<=0)) + ...
                            (1/(exCond + topCond)*(exp(-r.^2./(2*R^2)).*r./sqrt((r.*cos(phi)-offcenter).^2 + (r.*sin(phi)).^2 + (z - ze).^2)).*(z>0))).*(ze<0));
                        
                    IntBoundsR = [0, inf]; 
                    
                case 'infplane'
                    lb = -R;
                    ub = R;
                    
                        fun = @(z) RealCSD(z).*(...
                            (1/exCond*-1/(ub-lb)*((z-ub).*(ze-lb).*(ze<z) + (z-lb).*(ze-ub).*(ze>=z)) +...
                            (exCond-topCond)/(exCond + topCond).*-1/(ub-lb)*((-z-ub).*(ze-lb).*(ze<-z) + (-z-lb).*(ze-ub).*(ze>=-z))).*(ze >=0) +...
                            (1/topCond*-1/(ub-lb)*((z-ub).*(ze-lb).*(ze<z) + (z-lb).*(ze-ub).*(ze>=z)) +...
                            (topCond-exCond)/(exCond + topCond).*-1/(ub-lb)*((-z-ub).*(ze-lb).*(ze<-z) + (-z-lb).*(ze-ub).*(ze>=-z))).*(ze<0) );
                
                case 'point'
                    fun = @(z,r) (1/(4*pi*exCond)*(1/sqrt((r-offcenter)^2+(z - ze)^2)+...
                        (exCond-topCond)/(exCond + topCond)*(1/sqrt(r-offcenter)^2+(z + ze)^2)).*(z>=0) + ...
                        1/(exCond + topCond)*(1/sqrt(r-offcenter)^2+(z - ze)^2).*(z<0)).*(ze>=0) + ...
                        (1/(4*pi*topCond)*(1/sqrt((r-offcenter)^2+(z - ze)^2)+...
                        (topCond-exCond)/(exCond + topCond)*(1/sqrt(r-offcenter)^2+(z + ze)^2)).*(z<=0) + ...
                        1/(exCond + topCond)*(1/sqrt(r-offcenter)^2+(z - ze)^2).*(z>0)).*(ze<0);
                    
                    pot = fun(SourceLoc,0);
                    return;
                    
            end
            
            %% Integrate over depth to get potential

            pot = integral3(fun, IntBounds(1),IntBounds(2), IntBoundsR(1),IntBoundsR(2),0,2*pi);% in mV
            
        end
        
    end
    
    methods % Dependent properties
        
        function Pot = get.Pot(C)
            Pot = C.NoiseFreePot + C.Noise;
        end
        
        function NumEl = get.NumEl(C)
            NumEl = length(C.ElectrodePositions);
        end
    end
end