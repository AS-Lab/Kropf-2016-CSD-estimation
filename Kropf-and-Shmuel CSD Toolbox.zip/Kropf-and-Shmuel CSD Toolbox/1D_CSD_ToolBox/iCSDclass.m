%% Still to do:
% - Add the option of spatial filtering for the CSD (this could be added to
% the general function)

classdef iCSDclass < CSD2layer
    
    properties
        
        BasisShape; % Form of the basis elements used - either 'Delta', 'Step', 'StepA' 'Spline'
        
        SourceRegionBounds; % Where do the sources start and where do they end
        
    end
    
    properties (SetAccess = private)
        
        h; % median separation between contacts
        
        StepBounds; % Boundaries of the different step functions
        
        E; % Cell containing the 4 E matrices needed for the spline method
        
        IntTol; % Tolerance used during integration
        
    end
    
    methods % Constructor
        
        function C = iCSDclass(ElectrodePositions, Param, TextOutput, BasisShape) % Constructor
            
            C = C@CSD2layer(ElectrodePositions, Param, TextOutput);
            
            C.BasisShape = BasisShape;
            
            C.CSDestMethod = 'iCSD';
            
        end
        
    end
    
    methods % Abstract methods defined in superclass
        
        function CalcF(C)
            
            switch lower(C.BasisShape)
                
                case 'delta'
                    
                    C.CalcFdelta;
                    C.SourceRegionBounds = [C.ElectrodePositions(1) C.ElectrodePositions(end)];
                    
                case 'step'
                    
                    C.CalcFstep;
                    C.SourceRegionBounds = [C.StepBounds(1,1) C.StepBounds(end,2)];
                    
                case 'stepa'
                    
                    C.CalcFstepA;
                    C.SourceRegionBounds = [C.StepBounds(1,1) C.StepBounds(end,2)];
                   
                case 'stepb'
                    
                    C.CalcFstepB;
                    C.SourceRegionBounds = [C.StepBounds(1,1) C.StepBounds(end,2)];
                    
                case 'spline'
                    
                    C.CalcFspline;
                    C.SourceRegionBounds = [C.ElectrodePositions(1)-C.h C.ElectrodePositions(end)+C.h];
            end
            
        end
        
        function H = CalcNormMat(C,order, ordertype, ExtraReg, ExtraRegRegions)
            if strcmpi(C.BasisShape,'spline')
                if ExtraReg % Add extra regularization (penalize norm) in specified regions
                    % Only penalizes the coeffs right now and not the model
                    % norm!
                    H = zeros(size(C.F,2));
                    el_pos_with_ends = zeros(1,C.NumEl);
                    el_pos_with_ends(1,1) = C.ElectrodePositions(1)- C.h;
                    el_pos_with_ends(2:C.NumEl+1) = C.ElectrodePositions(1:C.NumEl);
                    el_pos_with_ends(1,C.NumEl+2) = C.ElectrodePositions(C.NumEl)+C.h;
                    
                    
                    for k = 1:size(ExtraRegRegions,1)
                        int_bounds = ExtraRegRegions(k,1:2);
                        weight = ExtraRegRegions(k,3);
                        H1 = diag(weight*(el_pos_with_ends >= int_bounds(1) & el_pos_with_ends <= int_bounds(2)));
                        
                        H = H+H1'*H1;
                    end
                end
            
                switch lower(ordertype)
                    case 'model'
                        if ~ExtraReg
                            H = zeros(size(C.F,2));
                            el_pos_with_ends = zeros(1,C.NumEl);
                            el_pos_with_ends(1,1) = C.ElectrodePositions(1)- C.h;
                            el_pos_with_ends(2:C.NumEl+1) = C.ElectrodePositions(1:C.NumEl);
                            el_pos_with_ends(1,C.NumEl+2) = C.ElectrodePositions(C.NumEl)+C.h;
                        end
                    
                        d = diag(diff(el_pos_with_ends));
                        for ord = 1:length(order)
                            switch order(ord)
                                case 0
                                    H1 = C.E{1}'*d*C.E{1} + C.E{1}'*d.^2/2*C.E{2} + C.E{2}'*d.^2/2*C.E{1} + C.E{2}'*d.^3/3*C.E{2} +...
                                        C.E{1}'*d.^3/3*C.E{3} + C.E{3}'*d.^3/3*C.E{1} + C.E{2}'*d.^4/4*C.E{3} + C.E{3}'*d.^4/4*C.E{2} +...
                                        C.E{1}'*d.^4/4*C.E{4} + C.E{4}'*d.^4/4*C.E{1} + C.E{3}'*d.^5/5*C.E{3} + ...
                                        C.E{2}'*d.^5/5*C.E{4} + C.E{4}'*d.^5/5*C.E{2} + C.E{3}'*d.^6/6*C.E{4} + C.E{4}'*d.^6/6*C.E{3} + ...
                                        C.E{4}'*d.^7/7*C.E{4};
                                case 1
                                    H1 = C.E{2}'*d*C.E{2} + C.E{2}'*d.^2*C.E{3} + C.E{3}'*d.^2*C.E{2} + C.E{3}'*(d.^3*4/3)*C.E{3} + ...
                                        C.E{2}'*d.^3*C.E{4} + C.E{4}'*d.^3*C.E{2} + C.E{3}'*(d.^4*6/4)*C.E{4} + C.E{4}'*(d.^4*6/4)*C.E{3} + ...
                                        C.E{4}'*d.^5*9/5*C.E{4};
                                case 2
                                    H1 = C.E{3}'*d*4*C.E{3} + C.E{3}'*d.^2*6*C.E{4} + C.E{4}'*d.^2*6*C.E{3} + C.E{4}'*d.^3*12*C.E{4};
%                                     H1 = sqrt(d*4)*C.E{3} + sqrt(d.^2*6)*C.E{4} + sqrt(d.^2*6)*C.E{3} + sqrt(d.^3*12)*C.E{4};
                            end
                            
                            H = H+H1;
                        end
%                         if length(order)>1
                            [H,p] = chol(H);
                            if p ~= 0
                                warning('Cholesky factorization has failed because matrix was found to not be positive-definite. A quick fix is attempted...');
                                H = cat(2,H,zeros(size(H,1),p-size(H,2)));
                            end
%                         end
                        
                    case 'coeff'
                        if ~ExtraReg
                            H = zeros(size(C.F,2));
                        end
                        
                        for ord = 1:length(order)
                            
%                             H1 = full(get_l(size(C.F,2),order(ord)));
                            
                            switch order(ord)
                                case 0
                                    H1 = full(get_l(size(C.F,2),order(ord)));
                                case 1
                                    H1 = cat(1, [1 zeros(1,size(C.F,2)-1)], full(get_l(size(C.F,2),order(ord))));
                                case 2
                                    H1 = cat(1, [-2 1 zeros(1,size(C.F,2)-2)], full(get_l(size(C.F,2),order(ord))),...
                                        [zeros(1,size(C.F,2)-2) 1 -2]);
                            end
                            
                            if length(order)>1 || ExtraReg
                                H = H+H1'*H1;
                            else
                                H = H1;
                            end
                        end
                        if length(order)>1 || ExtraReg
                            H = chol(H);
                        end
                end
            else
                H = zeros(size(C.F,2));
                for ord = 1:length(order)
                    
                    H1 = get_l(size(C.F,2),order(ord));
                    
                    if length(order)==1
                        H = H1;
                    else
                        H = H+H1'*H1;
                    end
                end
                if length(order)>1
                    H = chol(H);
                end
            end

        end
        
        function FindIdealWeights(C)
            %% HAVE TO CHECK THIS!
            
            srcFunc = C.SimPotObj.RealCSD;
            if size(C.F,1) > C.NumEl % Add an imaginary zero potential at the top and bottom for the iCSD spline method
                w = srcFunc([C.ElectrodePositions(1)-C.h; C.ElectrodePositions; C.ElectrodePositions(end)+C.h]);
            else
                w = srcFunc(C.ElectrodePositions);
            end
            
            C.IdealBasisWeights = repmat(reshape(C.SimPotObj.SourceInt,[1 C.NumSamples C.NumTrials]),[size(C.F,1) 1 1])...
                .*repmat(w,[1 C.NumSamples C.NumTrials]);
            
        end
        
        function Err2norm = GetWeightMisfitNorm(C, IdealBasisWeights,EstimatedWeights)
            %% NEED TO ACCOUNT FOR POSSIBLE UNREGULAR SAMPLING
            
            misfit = IdealBasisWeights - EstimatedWeights;
            
            sampling = C.h; % Only valid for a regular grid
            
            Err2norm = sampling*sum(misfit.^2); 
            
        end
        
        function CSDest = CalcCSDest(C, weights)
            
            if ~isempty(weights)
                
                switch lower(C.BasisShape)
                    
                    case 'delta'
                        CSDest = C.CalcCSDestDelta(weights);
                        
                    case 'step'
                        CSDest = C.CalcCSDestStep(weights);
                    
                    case 'stepa'
                        CSDest = C.CalcCSDestStep(weights);
                       
                    case 'stepb'
                        CSDest = C.CalcCSDestStep(weights);
                        
                    case 'spline'
                        CSDest = C.CalcCSDestSpline(weights);
                        
                end
                
            end
        end
        
        function CalcResMat(C,weights)
            
            switch lower(C.BasisShape)
                
                case 'delta'
                    C.CalcResMatDelta(weights)
                    
                case 'step'
                    C.CalcResMatStep(weights)
                    
                case 'stepa'
                    C.CalcResMatStep(weights)
                    
                case 'stepb'
                    C.CalcResMatStep(weights)
                    
                case 'spline'
                    C.CalcResMatSpline(weights)
                    
            end
        end
        
        function ResetReadOutClassSpecific(C)
            
        end
        
    end
    
    methods (Access = private) % Delta Methods
        
        function CalcFdelta(C)
            
            % Modified function F_delta by Pascal Kropf from Klas H. Pettersen:
            % Original copyright info below
            %
            %Computes the F-matrix from infinitesimally thin current source density
            %sheets with diameter d and homogenous activity throughout the sheet.
            
            %Copyright 2005 Klas H. Pettersen under the General Public License,
            %
            %This program is free software; you can redistribute it and/or
            %modify it under the terms of the GNU General Public License
            %as published by the Free Software Foundation; either version 2
            %of the License, or any later version.
            %
            %See: http://www.gnu.org/copyleft/gpl.html
            
            N = C.NumEl;
            
            R = C.R;
            el_pos = C.ElectrodePositions;
            C.h = median(diff(el_pos));
            
            fun = C.ForwardFunc;
            
            out = zeros(N);
            for j=1:N                     %zs is position of CSD-plane
                zs = el_pos(j);
                for i=1:N                   %ze is position of electrode
                    ze = el_pos(i);
                    
                    out(j,i) = C.h*fun(zs,ze,R); 
                    
                end; %for i
            end; %for j
            C.F = out;
            
            C.SourceRegionBounds = [el_pos(1) el_pos(N)];
            
        end
        
        function CSDest = CalcCSDestDelta(C, weights)
            
            ElPos = C.ElectrodePositions;
            
            weights = reshape(weights, [C.NumEl C.NumSamples*C.NumTrials]);
            CSDest = zeros(C.NumReadOut, C.NumSamples*C.NumTrials);
            
            for i = 1:C.NumEl
                idx = find(round(ElPos(i)*10^6) == round(C.ReadOutRegion*10^6),1);
                if ~isempty(idx)
                    CSDest(idx,:) = weights(i,:);
                else
                    disp(['Electrode Position' num2str(ElPos(i),4) ' is not in the ReadOutRegion and therefore left out']);
                end
            end
            
%             weights = reshape(weights, [C.NumEl C.NumSamples C.NumTrials]);
            CSDest = reshape(CSDest, [C.NumReadOut C.NumSamples C.NumTrials]);
            
        end
        
        function CalcResMatDelta(C, weights)
            
            C.ResMat = nan(C.NumReadOut, C.NumReadOut);
            
            ElPos = C.ElectrodePositions;
            
            for i = 1:C.NumEl
                idx = find(round(ElPos(i)*10^6) == round(C.ReadOutRegion*10^6),1);
                if ~isempty(idx)
                    C.ResMat(idx,:) = weights(i,:);
                else
                    disp(['Electrode Position' num2str(ElPos(i),4) ' is not in the ReadOutRegion and therefore left out']);
                end
            end
              
        end

    end
    
    methods (Access = private) % Step Methods
        
        function CalcFstep(C)
            %% Function
            % Creates the F-matrix by always putting the source between
            % [el-h el+h]. So if there is a bad channel then there will be 
            % an empty region without sources in the gap.
            % Sources are allowed to cross the boundary between two media (at 0)
            
            C.IntTol = 1e-6;
            tol = C.IntTol;
             
            el_pos = C.ElectrodePositions;
            N = length(el_pos);
            
            C.h = median(diff(C.ElectrodePositions));
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            so_pos = el_pos;        % Position of sources
            out = zeros(N);
            C.StepBounds = nan(N,2);
            
            for j = 1:N            %rows
                ze = el_pos(j);   %electrode positions
                for i = 1:N %columns
                    lower_int = so_pos(i)-C.h/2;
                    upper_int = so_pos(i)+C.h/2;
                    
%                     fun2 = @(zs) fun(zs,ze,R);
%                     out(j,i) = quadgk(fun2,lower_int,upper_int);
                    fun_t = @(zs) fun(zs,ze,R);
                    out(j,i) = quadgk(fun_t,lower_int,upper_int);
                    
                    C.StepBounds(i,1) = lower_int;
                    C.StepBounds(i,2) = upper_int;
                end
            end
            C.F = out;
            
        end
        
        function CalcFstepA(C)
            %% Function
            % Creates the F-matrix by putting the sources mid way between
            % electrode positions. It also doesn't make sources cross the
            % boundary between media. If an electrode is placed at 0, the
            % source will only extend inwards
            
            C.IntTol = 1e-6;
            tol = C.IntTol; 
            el_pos = C.ElectrodePositions;
            N = length(el_pos);
            
            C.h = median(diff(C.ElectrodePositions));
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            zero_el = find(el_pos == 0);
            if isempty(zero_el), zero_el = nan; end
            so_pos = el_pos;        % Position of sources
            out = zeros(N);
            C.StepBounds = nan(N,2);
            for j = 1:N            %rows
                ze = el_pos(j);   %electrode positions
                for i = 1:N %columns
                    if so_pos(i) < 0 % source outside
                        if i~=1 %define lower integral limit
                            lower_int = so_pos(i)-(so_pos(i)-so_pos(i-1))/2;
                        else
                            lower_int = so_pos(i)-C.h/2;
                        end
                        
                        if i~= N && (so_pos(i+1) > 0 || i+1 == zero_el) % next electrode is either at 0 or greater than 0
                            upper_int = 0; % This is to take care of the region around the surface
                        elseif i~=N %define upper integral limit
                            upper_int = so_pos(i)+(so_pos(i+1)-so_pos(i))/2;
                        elseif i == N && so_pos(i)+C.h/2 > 0 % This is the case when the last electrode is closer than h/2 to the surface
                            upper_int = 0;
                        else % last electrode and completely outside
                            upper_int = so_pos(i)+C.h/2;
                        end
                        fun_t = @(zs) fun(zs,ze,R);
                        out(j,i) = quadgk(fun_t,lower_int,upper_int);
                    
                        
                    elseif so_pos(i) >= 0 % Source inside
                        if i~=1 && so_pos(i-1) < 0  %define lower integral limit
                            lower_int = 0;
                        elseif i ~= 1
                            lower_int = so_pos(i)-(so_pos(i)-so_pos(i-1))/2;
                        elseif i == 1 && so_pos(i)-C.h/2 < 0
                            lower_int = 0;
                        else
                            lower_int = so_pos(i)-C.h/2;
                        end
                        
                        if i~= N
                            upper_int = so_pos(i)+(so_pos(i+1)-so_pos(i))/2;
                        else
                            upper_int = so_pos(i)+C.h/2;
                        end
                        fun_t = @(zs) fun(zs,ze,R);
                        out(j,i) = quadgk(fun_t,lower_int,upper_int);
                        
                    end
                    C.StepBounds(i,1) = lower_int;
                    C.StepBounds(i,2) = upper_int;
                end; %for i
            end %for j
            
            C.F = out;
            
        end
        
        function CalcFstepB(C)
            %% Function
            % Creates the F-matrix by putting the sources mid way between
            % electrode positions. So if there is a bad channel in the middle
            % then the sources will fill the void.
            % Sources are allowed to cross the boundary between two media (at 0)
            
            C.IntTol = 1e-6;
            tol = C.IntTol;
            
            R = C.R; 
            
            el_pos = C.ElectrodePositions;
            N = length(el_pos);
            
            C.h = median(diff(C.ElectrodePositions));
            
            fun = C.ForwardFunc;
            
            so_pos = el_pos;        % Position of sources
            out = zeros(N);
            C.StepBounds = nan(N,2);
            for j = 1:N            %rows
                ze = el_pos(j);   %electrode positions
                for i = 1:N %columns
                    
                    if i ~= 1
                        lower_int = so_pos(i)-(so_pos(i)-so_pos(i-1))/2;
                    else
                        lower_int = so_pos(i)-C.h/2;
                    end
                    
                    if i~= N
                        upper_int = so_pos(i)+(so_pos(i+1)-so_pos(i))/2;
                    else
                        upper_int = so_pos(i)+C.h/2;
                    end
                    fun_t = @(zs) fun(zs,ze,R);
                    out(j,i) = quadgk(fun_t,lower_int,upper_int);
                    
                    C.StepBounds(i,1) = lower_int;
                    C.StepBounds(i,2) = upper_int;
                end; %for i
            end %for j
            
            C.F = out;
            
        end
        
        function CSDest = CalcCSDestStep(C, basisweights)
            
            el_pos = C.ElectrodePositions;
            
            z = C.ReadOutRegion;
            
            basisweights = reshape(basisweights, [C.NumEl C.NumSamples*C.NumTrials]);
            
            CSDest = nan(C.NumReadOut, C.NumSamples*C.NumTrials);
            
            CSDest(z<C.StepBounds(1,1)| z>=C.StepBounds(end,2),:) = 0;
            for i = 1:size(C.StepBounds,1)
                
                idx = z>=C.StepBounds(i,1)&z<C.StepBounds(i,2);
                numDepths = sum(idx);
                
                if numDepths ~= 0;
                    CSDest(idx,:) = repmat(basisweights(i,:),numDepths,1);
                else
                    disp(['Source Position' num2str(el_pos(i),4) ' is not in the ReadOutRegion and therefore not displayed']);
                end
                
            end
            
%             C.BasisWeights = reshape(C.BasisWeights, [C.NumEl C.NumSamples C.NumTrials]);
            CSDest = reshape(CSDest, [C.NumReadOut C.NumSamples C.NumTrials]);
        end
        
        function CalcResMatStep(C, weights)
            
            el_pos = C.ElectrodePositions;
            
            z = C.ReadOutRegion;
            
            C.ResMat = nan(C.NumReadOut, C.NumReadOut);
            
            C.ResMat(z<C.StepBounds(1,1)| z>=C.StepBounds(end,2),:) = 0;
            
            for i = 1:size(C.StepBounds,1)
                
                idx = z>=C.StepBounds(i,1)&z<C.StepBounds(i,2);
                numDepths = sum(idx);
                
                if numDepths ~= 0;
                    C.ResMat(idx,:) = repmat(weights(i,:),numDepths,1);
                else
                    disp(['Source Position' num2str(el_pos(i),4) ' is not in the ReadOutRegion and therefore not displayed']);
                end
                
            end
            
        end
        
    end
    
    methods (Access = private) % Spline Methods
        
        function CalcFspline(C)
            
            C.IntTol = 1e-6;
            tol = C.IntTol;
            
            el_pos = C.ElectrodePositions(:)';
            
            % Define positions and constants
            N = length(el_pos);     %number of electrodes
            z_js = zeros(1,N+2);            %declare electrode positions included
            z_js(1,2:N+1) = el_pos(1,:);    %two imaginary, first electrode in z = 0
            
            % Modified by Pascal
            %   h_av = sum(diff(el_pos))/(N-1); %average inter-contact distance
            C.h = median(abs(diff(el_pos))); % Median inter-contact distance
            % End of modification
            
            z_js(1,1) = z_js(1,2)- C.h;    %first imaginary electrode position
            z_js(1,N+2) = z_js(1,N+1)+C.h; %last imaginary electrode position
            
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            f1 = @(zs,ze,zi,R) (zs-zi).*fun(zs,ze,R);
            f2 = @(zs,ze,zi,R) (zs-zi).^2.*fun(zs,ze,R);
            f3 = @(zs,ze,zi,R) (zs-zi).^3.*fun(zs,ze,R);
            
            C.compute_Ematrixes(el_pos);
            
            %   Define integration matrixes
            F0  = zeros(N,N+1);
            F1  = zeros(N,N+1);
            F2  = zeros(N,N+1);
            F3  = zeros(N,N+1);
            
            for j = 1:N            %rows (Electrode Position)
                %   progress = [num2str(j) ' of ' num2str(N) ': int. tolereance: ' num2str(tol)]
                for i = 1:N+1           %columns (Source positions)
                    
                    fun_t = @(zs) fun(zs,z_js(j+1),R);
                    f1_t = @(zs) f1(zs,z_js(j+1),z_js(i),R);
                    f2_t = @(zs) f2(zs,z_js(j+1),z_js(i),R);
                    f3_t = @(zs) f3(zs,z_js(j+1),z_js(i),R);
                    F0(j,i) = quadgk(fun_t,z_js(i),z_js(i+1));
                    F1(j,i) = quadgk(f1_t,z_js(i),z_js(i+1));
                    F2(j,i) = quadgk(f2_t,z_js(i),z_js(i+1));
                    F3(j,i) = quadgk(f3_t,z_js(i),z_js(i+1));
                    
                end
            end
            
            temp_F = F0*C.E{1}+F1*C.E{2}+F2*C.E{3}+F3*C.E{4};  %the F matrix, (N x N+2)
            
            %   Convert to (N+2xN+2) matrixes by applying the boundary I_0 = I_N+1 = 0.
            C.F = zeros(N+2);
            C.F(2:N+1,:) = temp_F(:,:);
            C.F(1,1) = 1;          %implies I_1 = Phi_1
            C.F(N+2,N+2) = 1;      %implies I_N+2 = Phi_N+2
            
            C.SourceRegionBounds = [z_js(1) z_js(end)];
            
        end
        
        function CSDest = CalcCSDestSpline(C,basisweights)
            
            NumSamples = size(basisweights,2);
            NumTrials = size(basisweights,3);
            
            CSD_coeff = reshape(basisweights, [size(C.F,1) NumSamples*NumTrials]);
            
            %The cubic spline polynomial coeffescients
            A0 = C.E{1}*CSD_coeff;
            A1 = C.E{2}*CSD_coeff;
            A2 = C.E{3}*CSD_coeff;
            A3 = C.E{4}*CSD_coeff;
            
            el_pos_with_ends = zeros(1,C.NumEl);
            el_pos_with_ends(1,1) = C.ElectrodePositions(1)- C.h;
            el_pos_with_ends(2:C.NumEl+1) = C.ElectrodePositions(1:C.NumEl);
            el_pos_with_ends(1,C.NumEl+2) = C.ElectrodePositions(C.NumEl)+C.h;
            
            out_zs = C.ReadOutRegion;
            
            CSDest = nan(C.NumReadOut, NumSamples*NumTrials);
            CSDest(out_zs<=el_pos_with_ends(1)| out_zs > el_pos_with_ends(end),:) = 0;
            
            idxes = 1:length(out_zs);
            for i = 1:length(el_pos_with_ends)-1
                idx = idxes(out_zs>el_pos_with_ends(i) & out_zs<=el_pos_with_ends(i+1));
                CSDest(idx,:) = repmat(A0(i,:),length(idx),1) +...
                    repmat(A1(i,:),length(idx),1).*repmat((out_zs(idx)-el_pos_with_ends(i))', 1, NumSamples*NumTrials) + ...
                    repmat(A2(i,:),length(idx),1).*repmat((out_zs(idx)-el_pos_with_ends(i)).^2', 1, NumSamples*NumTrials) + ...
                    repmat(A3(i,:),length(idx),1).*repmat((out_zs(idx)-el_pos_with_ends(i)).^3', 1, NumSamples*NumTrials);
            end
            CSDest = reshape(CSDest, [C.NumReadOut NumSamples NumTrials]);
            
        end
        
        function CalcResMatSpline(C, weights)
            
            NumCol = size(weights,2); % Number of columns
            
            CSD_coeff = weights;
            
            %The cubic spline polynomial coeffescients
            A0 = C.E{1}*CSD_coeff;
            A1 = C.E{2}*CSD_coeff;
            A2 = C.E{3}*CSD_coeff;
            A3 = C.E{4}*CSD_coeff;
            
            el_pos_with_ends = zeros(1,C.NumEl);
            el_pos_with_ends(1,1) = C.ElectrodePositions(1)- C.h;
            el_pos_with_ends(2:C.NumEl+1) = C.ElectrodePositions(1:C.NumEl);
            el_pos_with_ends(1,C.NumEl+2) = C.ElectrodePositions(C.NumEl)+C.h;
            
            out_zs = C.ReadOutRegion;
            
            C.ResMat = nan(C.NumReadOut, NumCol);
            C.ResMat(out_zs<=el_pos_with_ends(1)| out_zs > el_pos_with_ends(end),:) = 0;
            
            idxes = 1:length(out_zs);
            for i = 1:length(el_pos_with_ends)-1
                idx = idxes(out_zs>el_pos_with_ends(i) & out_zs<=el_pos_with_ends(i+1));
                C.ResMat(idx,:) = repmat(A0(i,:),length(idx),1) +...
                    repmat(A1(i,:),length(idx),1).*repmat((out_zs(idx)-el_pos_with_ends(i))', 1, NumCol) + ...
                    repmat(A2(i,:),length(idx),1).*repmat((out_zs(idx)-el_pos_with_ends(i)).^2', 1, NumCol) + ...
                    repmat(A3(i,:),length(idx),1).*repmat((out_zs(idx)-el_pos_with_ends(i)).^3', 1, NumCol);
            end
            
        end
        
        function compute_Ematrixes(C,el_pos)
            %function [E0,E1,E2,E3] = compute_Ematrixes(el_pos)
            %
            %Computes the E0, E1, E2 and E3 matrixes used in the cubic spline iCSD
            %method. These matrixes contains the recursive formulas for finding the F
            %matrix (see paper appendix).
            
            %Copyright 2005 Klas H. Pettersen under the General Public License,
            %
            %This program is free software; you can redistribute it and/or
            %modify it under the terms of the GNU General Public License
            %as published by the Free Software Foundation; either version 2
            %of the License, or any later version.
            %
            %See: http://www.gnu.org/copyleft/gpl.html
            el_pos = el_pos(:)';
            N = length(el_pos);
            z_js = zeros(1,N+2);            %declare electrode positions included ...
            z_js(1,2:N+1) = el_pos(1,:);    %two imaginary, first electrode in z = 0.
            %   h_av = sum(diff(el_pos))/(N-1); %average inter-contact distance
%             h_av = median(diff(el_pos)); %average inter-contact distance
            z_js(1,1) = z_js(1,2)- C.h;    %first imaginary electrode position
            z_js(1,N+2) = z_js(1,N+1)+C.h; %last imaginary electrode position
            
            C_vec = 1./diff(z_js);          %length: N+1
            % Define transformation matrixes
            C_jm1 = zeros(N+2);
            C_j0 = zeros(N+2);
            C_jall = zeros(N+2);
            C_mat3 = zeros(N+1);
            
            for i=1:N+1
                for j=1:N+1
                    if i == j
                        C_jm1(i+1,j+1) = C_vec(i);
                        C_j0(i,j) = C_jm1(i+1,j+1);
                        C_mat3(i,j) = C_vec(i);
                    end;
                end;
            end;
            C_jm1(N+2,N+2) = 0;
            
            C_jall = C_j0;
            C_jall(1,1) = 1;
            C_jall(N+2,N+2) = 1;
            
            C_j0(1,1) = 0;
            
            Tjp1 = zeros(N+2);         %converting an element k_j to k_j+1
            Tjm1 = zeros(N+2);         %converting an element k_j to k_j-1
            Tj0  = eye(N+2);
            Tj0(1,1) = 0;
            Tj0(N+2,N+2) = 0;
            
            %C to K
            for i=2:N+2
                for j=1:N+2
                    if i==j-1
                        Tjp1(i,j) = 1;
                    end;
                    if i==j+1
                        Tjm1(i,j) = 1;
                    end;
                end;
            end;
            
            
            % C to K transformation matrix
            K = (C_jm1*Tjm1+2*C_jm1*Tj0+2*C_jall+C_j0*Tjp1)^(-1)*3*...
                (C_jm1^2*Tj0-C_jm1^2*Tjm1+C_j0^2*Tjp1-C_j0^2*Tj0);
            
            %   Define matrixes for C to A transformation
            Tja  = zeros(N+1,N+2);      %identity matrix except that it cuts off last elenent
            Tjp1a  = zeros(N+1,N+2);    %converting k_j to k_j+1 and cutting off last element
            
            
            %C to A
            for i=1:N+1
                for j=1:N+2
                    if i==j-1
                        Tjp1a(i,j) = 1;
                    end;
                    if i==j
                        Tja(i,j) = 1;
                    end;
                end;
            end;
            
            %   Define spline coeffiscients
            C.E{1}  = Tja;
            C.E{2}  = Tja*K;
            C.E{3}  = 3*C_mat3^2*(Tjp1a-Tja)-C_mat3*(Tjp1a+2*Tja)*K;
            C.E{4}  = 2*C_mat3^3*(Tja-Tjp1a)+C_mat3^2*(Tjp1a+Tja)*K;
        end
        
    end
    
end