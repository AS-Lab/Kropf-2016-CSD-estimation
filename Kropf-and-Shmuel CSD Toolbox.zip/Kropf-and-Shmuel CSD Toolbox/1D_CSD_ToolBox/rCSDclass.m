%% To do
% - Gaussian first and second derivative has not been verified
% - The integration bounds are not properly handled if
% SourceRegionBounds(1) >= 0 or SourceRegionBounds(2) <= 0

classdef rCSDclass < CSD2layer
    
    properties
        
        SourceRegionBounds; % Boundaries of the function space
        
    end
    
    properties (SetAccess = private)
        
        bSrcMat; % Matrix of representers at ReadOutPoints (NumReadOut, NumEl)
        
        Deriv1; % handle to the 1st and 2nd derivative of the representers
        
        Deriv2; % handle to the 2nd derivative of the representers
        
    end
    
    methods % Constructor
        
        function C = rCSDclass(ElectrodePositions, Param, TextOutput, SourceRegionBounds) % Constructor
            
            C = C@CSD2layer(ElectrodePositions, Param, TextOutput);
            
            C.SourceRegionBounds = SourceRegionBounds;
            
            C.CSDestMethod = 'rCSD';
            
        end
        
    end
    
    methods % Abstract methods defined in superclass
        
        function CalcF(C)
            
            % Computes the Gram matrix assuming a forward model of
            % uniformly distributed sources inside a cylinder of Diameter
            % C.Diameter. The medium is assumed to be made of 2-layers
            
            %% Used Variables:
            % ElectrodePosition
            % Diameter
            % Top and Ex Conductivity
            % SourceParametrization
            
            %% Output
            %
            % F Matrix: The Gram matrix of the representers
            
            %% Computation
            
            
            int_bounds = C.SourceRegionBounds;
            
            electrodePos = C.ElectrodePositions;
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            F = zeros(C.NumEl);
            for i = 1:C.NumEl
                for j = 1:i
                    
                    int = @(zs) fun(zs,electrodePos(i),R).*fun(zs,electrodePos(j),R);
                    
                    F(i,j) = quadgk(int,int_bounds(1),int_bounds(2));
                    
                    
                    if i ~= j
                        % This is because we only calculate the lower triangular part
                        % of the matrix since the matrix is symmetric
                        F(j,i) = F(i,j);
                    end
                end
                
            end
            
            C.F = F;
            
        end
        
        function CSDest = CalcCSDest(C, weights)
            
            if isempty(C.bSrcMat)
                C.bSrcMatrixCalc;
            end
            sz = size(weights);
            if length(sz) == 2
                sz(3) = 1;
            end
            
            basis_weights = reshape(weights, [sz(1) sz(2)*sz(3)]);
            
            CSDest = C.bSrcMat*basis_weights;
            
            CSDest = reshape(CSDest, [C.NumReadOut sz(2) sz(3)]);
            
        end
        
        function CalcResMat(C, weights)
            
            if isempty(C.bSrcMat)
                C.bSrcMatrixCalc;
            end
            C.ResMat = C.bSrcMat*weights;
            
        end
        
        function ResetReadOutClassSpecific(C)
            
            C.bSrcMat = [];
            
        end
        
    end
    
    methods
        
        function FindIdealWeights(C)
            
            if isempty(C.BadChannels)
                Pot = C.SimPotObj.NoiseFreePot;
            else
                Pot = C.SimPotObj.NoiseFreePot;
                Pot(C.BadChannels,:,:) = [];
            end
            C.IdealBasisWeights = pinv(C.F)*reshape(Pot, [C.NumEl C.NumSamples*C.NumTrials]);
            C.IdealBasisWeights = reshape(C.IdealBasisWeights, [C.NumEl C.NumSamples C.NumTrials]);
            
        end
        
        function Err2norm = GetWeightMisfitNorm(C, IdealBasisWeights,EstimatedWeights)
            
            misfit = IdealBasisWeights - EstimatedWeights;
            
            Err2norm = sqrt(misfit'*C.F*misfit);
            
        end
        
        function H = CalcNormMat(C,order, ordertype, ExtraReg, ExtraRegRegions)
            count = 0;
            if ExtraReg % Add extra regularization (penalize norm) in specified regions
                count = count+1;
                electrodePos = C.ElectrodePositions;
                
                R = C.R;
                H = zeros(C.NumEl);
                fun = C.ForwardFunc;
                
                for k = 1:size(ExtraRegRegions,1)
                    int_bounds = ExtraRegRegions(k,1:2);
                    weight = ExtraRegRegions(k,3);
                    H1 = zeros(C.NumEl);
                    for i = 1:C.NumEl
                        for j = 1:i
                            
                            int = @(zs) fun(zs,electrodePos(i),R).*fun(zs,electrodePos(j),R);
                            
                            H1(i,j) = weight*quadgk(int,int_bounds(1),int_bounds(2));
                            
                            if i ~= j
                                % This is because we only calculate the lower triangular part
                                % of the matrix since the matrix is symmetric
                                H1(j,i) = H1(i,j);
                            end
                        end
                        
                    end
                    H = H+H1;
                end
            end
                
            switch lower(ordertype)
                case 'model'
                    exCond = C.ExCond;
                    
                    topCond = C.TopCond;
                    
                    c = (exCond - topCond)/(exCond + topCond);
                    
                    if ~ExtraReg
                        H = zeros(C.NumEl);
                        
                        fun = C.ForwardFunc;
                    end
                    
                    for ord = 1:length(order)
                        count = count + 1;
                        switch order(ord)
                            case 0
                                
                                H1 = C.F;
                                
                            case 1
                                
                                % ze = position of the electrode
                                % zs = position of source
                                switch lower(C.SourceShape)
                                    case 'unicyl'
                                        d1 = @(zs,ze,R) 1/2*((ze-zs)./sqrt((ze-zs).^2 + R^2) - sign(ze-zs));
                                        
                                    case 'gaussian'
                                        d1 = @(zs,ze,R) 1/2*(sqrt(2*pi)/(2*R).*(ze-zs)*erfcx(abs(ze-zs)/(sqrt(2)*R)) - sign(ze-zs));
                                end
                                
                                switch C.NumLayers
                                    case 1
                                        fun = @(zs,ze,R) CSD2layer.Pot1Layer(zs,ze,R,C.ExCond,d1);
                                    case 2
                                        fun = @(zs,ze,R) CSD2layer.Pot2Layer(zs,ze,R,C.TopCond,C.ExCond,d1);
                                    case 3
                                        a = C.WhiteMatterDepth/2;
                                        fun = @(zs,ze,R) CSD2layer.Pot3LayerParallel(zs,ze,R, C.TopCond,C.ExCond, C.BottomCond,d1, a, C.N);
                                end
                                
                                C.Deriv1 = fun;
                                
                                % Integrate functions to create Norm Matrix
                                
                                int_bounds = C.SourceRegionBounds;
                                
                                electrodePos = C.ElectrodePositions;
                                
                                R = C.R;
                                
                                H1 = zeros(C.NumEl);
                                for i = 1:C.NumEl
                                    for j = 1:i
                                        
                                        int = @(zs) fun(zs,electrodePos(i),R).*fun(zs,electrodePos(j),R);
                                        intval = 0;
                                        % These cases are necessary because there
                                        % is a singularity at each electrode
                                        % position
                                        a = min([electrodePos(i) electrodePos(j)]);
                                        b = max([electrodePos(i) electrodePos(j)]);
                                        if a > int_bounds(1) && b <= int_bounds(2)
                                            intval = intval + quadgk(int,int_bounds(1),a);
                                            intval = intval + quadgk(int,a,b);
                                            intval = intval + quadgk(int,b,int_bounds(2));
                                        elseif a <= int_bounds(1) && b <= int_bounds(2)
                                            intval = intval + quadgk(int,int_bounds(1),b);
                                            intval = intval + quadgk(int,b,int_bounds(2));
                                        elseif a >= int_bounds(2)
                                            intval = intval + quadgk(int,int_bounds(1),int_bounds(2));
                                        elseif b <= int_bounds(1)
                                            intval = intval + quadgk(int,int_bounds(1),int_bounds(2));
                                        elseif a <= int_bounds(1) && b > int_bounds(2)
                                            intval = intval + quadgk(int,int_bounds(1),int_bounds(2));
                                        elseif a > int_bounds(1) && b > int_bounds(2)
                                            intval = intval + quadgk(int,int_bounds(1),a);
                                            intval = intval + quadgk(int,a,int_bounds(2));
                                        else
                                            error('Integral Case Not Found!')
                                        end
                                        
                                        H1(i,j) = intval;
                                        
                                        if i ~= j
                                            % This is because we only calculate the lower triangular part
                                            % of the matrix since the matrix is symmetric
                                            H1(j,i) = H1(i,j);
                                        end
                                    end
                                    
                                end
                                
                            case 2
                                
                                % ze = position of the electrode
                                % zs = position of source
                                switch lower(C.SourceShape)
                                    case 'unicyl'
                                        d2 = @(zs,ze,R) 1/2*(R^2./(sqrt((ze-zs).^2 + R^2).^3));
                                        
                                    case 'gaussian'
                                        d2 = @(zs,ze,R) 1/2*(sqrt(2*pi)/(2*R).*(((ze-zs).^2/R^2 + 1).*erfcx(abs(ze-zs)/(sqrt(2)*R)) - sqrt(2/pi)/R));
                                        
                                end
                                
                                switch C.NumLayers
                                    case 1
                                        fun = @(zs,ze,R) CSD2layer.Pot1Layer(zs,ze,R,C.ExCond,d2);
                                    case 2
                                        fun = @(zs,ze,R) CSD2layer.Pot2Layer(zs,ze,R,C.TopCond,C.ExCond,d2);
                                    case 3
                                        a = C.WhiteMatterDepth/2;
                                        fun = @(zs,ze,R) CSD2layer.Pot3LayerParallel(zs,ze,R, C.TopCond,C.ExCond, C.BottomCond,d2, a, C.N);
                                end
                                
                                C.Deriv2 = fun;
                                
                                % Integrate functions to create Norm Matrix
                                
                                int_bounds = C.SourceRegionBounds;
                                
                                electrodePos = C.ElectrodePositions;
                                
                                R = C.R;
                                
                                H1 = zeros(C.NumEl);
                                for i = 1:C.NumEl
                                    for j = 1:i
                                        
                                        int = @(zs) fun(zs,electrodePos(i),R).*fun(zs,electrodePos(j),R);
                                        
                                        H1(i,j) = quadgk(int,int_bounds(1),int_bounds(2));%...
                                        %                                     -2*fun(electrodePos(j),electrodePos(i),R)...
                                        %                                     -2*fun(electrodePos(i),electrodePos(j),R)...
                                        %                                     +4;
                                        
                                        if i ~= j
                                            % This is because we only calculate the lower triangular part
                                            % of the matrix since the matrix is symmetric
                                            H1(j,i) = H1(i,j);
                                        end
                                    end
                                    
                                end
                        end
                        H = H+H1;
                        
                    end
                    
                    
                    [H, p] = chol(H);
                    %   [H, p] = chol(H,'lower');
                    if p ~= 0
                        warning('Cholesky factorization has failed because matrix was found to not be positive-definite');
                    end
                    
                case 'coeff'
                    if ~ExtraReg
                        H = zeros(C.NumEl);
                    end
                    for ord = 1:length(order)
                        
                        switch order(ord)
                            case 0
                                H1 = full(get_l(size(C.F,2),order(ord)));
                            case 1
                                H1 = cat(1, [1 zeros(1,size(C.F,2)-1)], full(get_l(size(C.F,2),order(ord))));
                            case 2
                                H1 = cat(1, [-2 1 zeros(1,size(C.F,2)-2)], full(get_l(size(C.F,2),order(ord))),...
                                    [zeros(1,size(C.F,2)-2) 1 -2]);
                        end

                        if length(order)>1 || ExtraReg
                            H = H+H1'*H1;
                        else
                            H = H1;
                        end
                    end
                    
                    if length(order)>1 || ExtraReg
                        [H, p] = chol(H);
                        if p ~= 0
                            warning('Cholesky factorization has failed because matrix was found to not be positive-definite');
                        end
                    end
            end
        end
        
    end
    
    methods (Access = private)
        
        function bSrcMatrixCalc(C)
            
            electrodePos = C.ElectrodePositions;
            
            ReadOut = C.ReadOutRegion;
            
            int_bounds = C.SourceRegionBounds;
            
            mask = ReadOut >= int_bounds(1) & ReadOut <= int_bounds(2);
            
            fun = C.ForwardFunc;
            R = C.R;
            
            bSrcMat = nan(C.NumReadOut, C.NumEl);
            for i = 1:C.NumEl
                
                bSrcMat(:,i) = fun(ReadOut,electrodePos(i),R).*mask;
                
            end
            C.bSrcMat = bSrcMat;
            
        end
        
    end
    
end