
classdef qCSDclass < CSD2layer
    
    properties (SetAccess = private)
        
        QuadMethod; % What type of quadrature method is used
        
        SourceRegionBounds; % Where are the source boundaries
        
        NumQuadPoints;
        
        QuadPoints; % Location where quadrature is computed
        
    end
    
    properties (SetAccess = private)
        
        h; % Width of the integral subinterval
        
    end
    
    methods % Constructor
        
        function C = qCSDclass(ElectrodePositions, Param, TextOutput, QuadMethod, QuadPoints) % Constructor
            
            C = C@CSD2layer(ElectrodePositions, Param, TextOutput);
            
            C.QuadMethod = QuadMethod;
            
            if length(QuadPoints) > 3
                
                switch lower(C.QuadMethod)
                    case 'midpoint' % n subintervals, n nodes
                        C.NumQuadPoints = length(QuadPoints);
                        C.QuadPoints = QuadPoints(:);
                        C.h = median(diff(C.QuadPoints));
                        % midpoint is an open Newton-Cotes rule and
                        % therefore the integration boundaries are not
                        % nodes
                        C.SourceRegionBounds = [C.QuadPoints(1)-C.h/2 C.QuadPoints(end)+C.h/2]; 
                        
                    case 'trap' % (n-1) subintervals, n nodes
                        C.NumQuadPoints = length(QuadPoints);
                        C.QuadPoints = QuadPoints(:);
                        C.h = median(diff(C.QuadPoints));
                        % trapezoidal is a closed Newton-Cotes rule and
                        % therefore the integration boundaries are nodes
                        C.SourceRegionBounds = [C.QuadPoints(1) C.QuadPoints(end)];
                        
                    case 'simpson' % (n-1) subintervals, n nodes, n must be odd
                        C.NumQuadPoints = length(QuadPoints);
                        C.QuadPoints = QuadPoints(:);
                        C.h = median(diff(C.QuadPoints));
                        if rem(C.NumQuadPoints,2)==0 % had to be odd
                            disp('The number of QuadPoints (nodes) has to be odd in Simpsons rule.\nAn additional point has been added at the end (this changes the upper integration bound by h)')
                            C.NumQuadPoints = C.NumQuadPoints+1;
                            C.QuadPoints(end+1) = C.QuadPoints(end)+C.h;
                        end
                        
                        % Simpson is a closed Newton-Cotes rule and
                        % therefore the integration boundaries are nodes
                        C.SourceRegionBounds = [C.QuadPoints(1) C.QuadPoints(end)];
                    
                end
            else
                % Describe here how the input arguments are given
                switch lower(C.QuadMethod)
                    case 'midpoint' % n subintervals, n nodes
                        C.SourceRegionBounds = [QuadPoints(1) QuadPoints(2)];
                        C.NumQuadPoints = QuadPoints(3);
                        C.QuadPoints = linspace(QuadPoints(1), QuadPoints(2), 2*C.NumQuadPoints+2)';
                        C.QuadPoints = C.QuadPoints(2:2:end-1);
                        C.h = median(diff(C.QuadPoints));
                        
                    case 'trap' % (n-1) subintervals, n nodes
                        C.SourceRegionBounds = [QuadPoints(1) QuadPoints(2)];
                        C.NumQuadPoints = QuadPoints(3);
                        C.QuadPoints = linspace(QuadPoints(1), QuadPoints(2), C.NumQuadPoints)';
                        C.h = (QuadPoints(2) - QuadPoints(1))/(C.NumQuadPoints-1); %median(diff(C.QuadPoints));
                        
                    case 'simpson' % (n-1) subintervals, n nodes, n must be odd
                        C.SourceRegionBounds = [QuadPoints(1) QuadPoints(2)];
                        C.NumQuadPoints = QuadPoints(3);
                        if rem(C.NumQuadPoints,2) == 0 % has to be odd
                            disp('The number of QuadPoints (nodes) has to be odd in Simpsons rule. One more has been added')
                            C.NumQuadPoints = C.NumQuadPoints+1;
                        end
                        C.QuadPoints = linspace(QuadPoints(1), QuadPoints(2), C.NumQuadPoints)';
                        C.h = (QuadPoints(2) - QuadPoints(1))/(C.NumQuadPoints-1); %median(diff(C.QuadPoints));
                        
                end
            end
            
            C.CSDestMethod = 'qCSD';
            
        end
        
    end
    
    methods % Abstract methods defined in superclass
            
        function CalcF(C)
            
            switch lower(C.QuadMethod)
                case 'midpoint'
                    C.CalcMidPointF;
                    
                case 'trap'
                    C.CalcTrapF;
                    
                case 'simpson'
                    C.CalcSimpsonF;
            end
            
        end
        
        function CalcMidPointF(C)
            
            QuadWeight = C.h;
            
            electrodePos = C.ElectrodePositions;
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            F = zeros(C.NumEl, C.NumQuadPoints);
            
            zs = C.QuadPoints;
            for i = 1:C.NumEl
                
                F(i,:) = QuadWeight*fun(zs,electrodePos(i),R);
                
            end
            
            C.F = F;
            
        end
        
        function CSDest = CalcCSDest(C,BasisWeights)
            switch lower(C.QuadMethod)
                case 'midpoint'
                    CSDest = C.CalcOpenCSDest(BasisWeights);
                    
                case 'trap'
                    CSDest = C.CalcClosedCSDest(BasisWeights);
                    
                case 'simpson'
                    CSDest = C.CalcClosedCSDest(BasisWeights);
                    
            end
        end
        
        function CSDest = CalcOpenCSDest(C,BasisWeights)
            
            z = C.ReadOutRegion;
            
            SourceBounds = [C.QuadPoints-C.h/2 C.QuadPoints+C.h/2];
            
            BasisWeights = reshape(BasisWeights, [C.NumQuadPoints C.NumSamples*C.NumTrials]);
            
            CSDest = nan(C.NumReadOut, C.NumSamples*C.NumTrials);
            
            CSDest(z<SourceBounds(1,1)| z>=SourceBounds(end,2),:) = 0;
            idx1 = find(z>=SourceBounds(1,1),1,'first');
            if isempty(idx1), idx1 = 1;end
            idx2 = find(z<=SourceBounds(end,2),1,'last');
            if isempty(idx2), idx2 = length(z);end
            for i = idx1:idx2
                
                idx = find(z(i)>=SourceBounds(:,1)&z(i)<=SourceBounds(:,2));
                numDepths = sum(idx);
                
                if numDepths ~= 0;
                    CSDest(i,:) = mean(BasisWeights(idx,:));
                else
                    disp(['Something went wrong in the creation of the CSDest. Rework the CSDest']);
                end
                
            end
            
            CSDest = reshape(CSDest, [C.NumReadOut C.NumSamples C.NumTrials]);
             
        end
        
        function CalcResMat(C, weights)
            
            switch lower(C.QuadMethod)
                case 'midpoint'
                    C.ResMat = C.CalcOpenCSDest(weights);
                    
                case 'trap'
                    C.ResMat = C.CalcClosedCSDest(weights);
                    
                case 'simpson'
                    C.ResMat = C.CalcClosedCSDest(weights);
                    
            end
            
        end
        
        function ResetReadOutClassSpecific(C)
            
            % There is nothing to reset
            
        end
        
        function CalcTrapF(C)
            
            QuadWeight = C.h;
            
            electrodePos = C.ElectrodePositions;
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            F = zeros(C.NumEl, C.NumQuadPoints);
            
            zs = C.QuadPoints;
            for i = 1:C.NumEl
                
                F(i,1) = QuadWeight/2*fun(zs(1),electrodePos(i),R);
                F(i,2:end-1) = QuadWeight*fun(zs(2:end-1),electrodePos(i),R);
                F(i,end) = QuadWeight/2*fun(zs(end),electrodePos(i),R);
                
            end
            
            C.F = F;
            
        end
        
        function CalcSimpsonF(C)
            
            QuadWeight = C.h;
            
            electrodePos = C.ElectrodePositions;
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            F = zeros(C.NumEl, C.NumQuadPoints);
            
            zs = C.QuadPoints;
            for i = 1:C.NumEl
                
                F(i,1) = QuadWeight/3*fun(zs(1),electrodePos(i),R);
                F(i,2:2:end) = 4*QuadWeight/3*fun(zs(2:2:end),electrodePos(i),R);
                F(i,3:2:end) = 2*QuadWeight/3*fun(zs(3:2:end),electrodePos(i),R);
                F(i,end) = QuadWeight/2*fun(zs(end),electrodePos(i),R);
                
            end
            
            C.F = F;
            
        end
        
        function CSDest = CalcClosedCSDest(C, BasisWeights)
            
            z = C.ReadOutRegion;
            
            SourceBounds = [C.QuadPoints-C.h/2 C.QuadPoints+C.h/2];
            
            SourceBounds(1,1) = C.SourceRegionBounds(1);
            SourceBounds(end,2) = C.SourceRegionBounds(2);
            
            sz = size(BasisWeights);
            if length(sz) == 2
                sz(3) = 1;
            end
            BasisWeights = reshape(BasisWeights, [sz(1) sz(2)*sz(3)]);
            
            CSDest = nan(C.NumReadOut, sz(2)*sz(3));
            
            CSDest(z<SourceBounds(1,1)| z>=SourceBounds(end,2),:) = 0;
            idx1 = find(z<=SourceBounds(1,1),1,'last');
            if isempty(idx1), idx1 = 1;end
            idx2 = find(z>=SourceBounds(end,2),1,'first');
            if isempty(idx2), idx2 = length(z);end
            for i = idx1:idx2
                
                idx = find(z(i)>=SourceBounds(:,1)&z(i)<=SourceBounds(:,2));
                numDepths = sum(idx);
                
                if numDepths ~= 0;
                    CSDest(i,:) = mean(BasisWeights(idx,:),1);
                else
                    disp(['Something went wrong in the creation of the CSDest. Rework the CSDest']);
                end
                
            end
            
            CSDest = reshape(CSDest, [C.NumReadOut sz(2) sz(3)]);
             
        end
    end
    
    methods %(Access = protected)
        
        function FindIdealWeights(C)
            
            srcFunc = C.SimPotObj.RealCSD;
            
            w = srcFunc(C.QuadPoints);
            
            C.IdealBasisWeights = repmat(reshape(C.SimPotObj.SourceInt,[1 C.NumSamples C.NumTrials]),[C.NumQuadPoints 1 1])...
                .*repmat(w,[1 C.NumSamples C.NumTrials]);
            
        end
        
        function Err2norm = GetWeightMisfitNorm(C, IdealBasisWeights,EstimatedWeights)
            %% THIS NEEDS TO BE ADAPTED ACCORDING TO THE OPEN OR CLOSED ESTIMATION
            % NEED TO ACCOUNT FOR POSSIBLE UNREGULAR SAMPLING
            
            misfit = IdealBasisWeights - EstimatedWeights;
            
            sampling = median(diff(C.QuadPoints)); % Only valid for a regular grid
            
            Err2norm = sampling*sum(misfit.^2); 
            
        end
        
        function H = CalcNormMat(C,order, ordertype, ExtraReg, ExtraRegRegions)
            
            if ExtraReg % Add extra regularization (penalize norm) in specified regions
                
                H = zeros(size(C.F,2));
                for k = 1:size(ExtraRegRegions,1)
                    bounds = ExtraRegRegions(k,1:2);
                    weight = ExtraRegRegions(k,3);
                    H1 = zeros(size(C.F,2),1);
                    H1(C.QuadPoints >= bounds(1) & C.QuadPoints <= bounds(2)) = weight;
                    H1 = diag(H1);
                    
                    H = H + H1;
                end
            else
                H = zeros(size(C.F,2));
            end
            
            for ord = 1:length(order)
                
                switch order(ord)
                    case 0
                        H1 = full(get_l(size(C.F,2),order(ord)))*sqrt(C.h);
                    case 1
                        H1 = cat(1, [1 zeros(1,size(C.F,2)-1)], full(get_l(size(C.F,2),order(ord))))/C.h*sqrt(C.h);
                    case 2
                        H1 = cat(1, [-2 1 zeros(1,size(C.F,2)-2)], full(get_l(size(C.F,2),order(ord))),...
                            [zeros(1,size(C.F,2)-2) 1 -2])/C.h^2*sqrt(C.h);
                end

                if length(order)>1 || ExtraReg
                    H = H+H1'*H1;
                else
                    H = H1;
                end
            end
            if length(order)>1 || ExtraReg
                H = chol(H);
            end
            
        end
        
    end
    
end