
classdef kCSDclass < CSD2layer
    
    properties (SetAccess = private)
        
        BasisShape; % Form of the basis elements used - either 'Gaussian' or 'Step'
        
        SourceRegionBounds; % Where should the sources be placed
        
        NumSrc; % Number of sources
        
        w; % Width of the sources (called R in kCSD)
        
    end
    
    properties (SetAccess = private)
        
        BasisFunc; % Handle to the basis function used, first argument = depth, second argument = position
        
        Src; % Center position of the sources - in mm
        
        bPotMat; % Matrix of basis functions in the space of potentials (NumSrc, NumEl)
        
        bSrcMat; % Matrix of basis functions in the space of CSD (NumReadOut, NumSrc)
        
        NormMeasMat; % Matrix used for measuring the norm of the estimated using the BasisWeights (Norm = b'*NormMeasMat*b where b are the weights)
        
    end
    
    methods % Constructor
        
        function C = kCSDclass(ElectrodePositions, Param, TextOutput, SourceRegionBounds, BasisShape, NumSrc, w) % Constructor
            
            C = C@CSD2layer(ElectrodePositions, Param, TextOutput);
            
            C.BasisShape = BasisShape;
            
            C.SourceRegionBounds = SourceRegionBounds;
            
            C.NumSrc = NumSrc;
            
            C.w = w;
            
            C.CSDestMethod = 'kCSD';
            
        end
        
    end
    
    methods %(Access = protected)% Abstract methods defined in superclass
        
        function CalcF(C)
            
            C.MakeSrc;
            
            C.bPotMatrixCalc;
            
            C.F =(C.bPotMat)'*(C.bPotMat); % This is called KPot in kCSD
            
            C.GetNormMeasMat; % Norm = b'*NormMeasMat*b where b are the weights
            
        end
        
        function CSDest = CalcCSDest(C,BasisWeights)
            
            C.bSrcMatrixCalc;
            
            interpCross = C.bSrcMat*C.bPotMat;
            
            BasisWeights = reshape(BasisWeights, [C.NumEl C.NumSamples*C.NumTrials]);
            
            CSDest = interpCross*BasisWeights;
            
            CSDest = reshape(CSDest, [C.NumReadOut C.NumSamples C.NumTrials]);
            
        end
        
        function CalcResMat(C, weights)
            
            interpCross = C.bSrcMat*C.bPotMat;
            
            C.ResMat = interpCross*weights;
            
        end
        
        function ResetReadOutClassSpecific(C)
            
            C.bSrcMat = [];
            
        end
        
        function FindIdealWeights(C)
            
            int_bounds = C.SourceRegionBounds;
            
            electrodePos = C.ElectrodePositions;
            
            R = C.R;
            
            fun = C.ForwardFunc;
            
            srcFunc = C.SimPotObj.RealCSD;
            
            w1 = zeros(C.NumEl,C.NumSamples,C.NumTrials);
            SourceInt = C.SimPotObj.SourceInt;
            NumTrials = C.NumTrials;
            NumSamples = C.NumSamples;
            for i = 1:C.NumEl
                
                int = @(zs) fun(zs,electrodePos(i),R).*srcFunc(zs);
                
                w2 = quadgk(int,int_bounds(1),int_bounds(2));
                w1(i,:,:) = SourceInt.*repmat(w2,[NumSamples NumTrials]);
                
            end
            
            w1 = reshape(w1,[C.NumEl C.NumSamples*C.NumTrials]);
            C.IdealBasisWeights = pinv(C.F)*w1;
            C.IdealBasisWeights = reshape(C.IdealBasisWeights, [C.NumEl C.NumSamples C.NumTrials]);
            
        end
        
        function GetNormMeasMat(C)
            
            Func = C.BasisFunc;
            
            A = zeros(C.NumSrc,C.NumSrc);
            for i = 1:C.NumSrc
                for j = 1:i
                    
                    g_int = @(zs) Func(zs, C.Src(i)) .* Func(zs, C.Src(j)) ;
                    A(i,j) = quadgk(g_int, C.SourceRegionBounds(1)-C.w,C.SourceRegionBounds(2)+C.w);
                    
                    if i ~= j
                        A(j,i) = A(i,j);
                    end
                end
            end
            
            H1 = zeros(size(C.F));
            for i = 1:C.NumEl
                for j = 1:i
                    
                    H1(i,j) = C.bPotMat(:,i)'*A*C.bPotMat(:,j);
                    if i ~= j
                        H1(j,i) = H1(i,j);
                    end
                end
            end
            
            C.NormMeasMat = H1;
        end
        
        function H = CalcNormMat(C,order, ordertype, ExtraReg, ExtraRegRegions)
            
            if ExtraReg
                H = zeros(size(C.F,2));
                Func = C.BasisFunc;
                for k = 1:size(ExtraRegRegions,1)
                    int_bounds = ExtraRegRegions(k,1:2);
                    weight = ExtraRegRegions(k,3);
                    A = zeros(C.NumSrc,C.NumSrc);
                    for i = 1:C.NumSrc
                        for j = 1:i
                            
                            g_int = @(zs) Func(zs, C.Src(i)) .* Func(zs, C.Src(j)) ;
                            A(i,j) = weight*quadgk(g_int, int_bounds(1),int_bounds(2));
                            
                            if i ~= j
                                A(j,i) = A(i,j);
                            end
                        end
                    end
                    H1 = zeros(size(C.F));
                    for i = 1:C.NumEl
                        for j = 1:i
                            
                            H1(i,j) = C.bPotMat(:,i)'*A*C.bPotMat(:,j);
                            if i ~= j
                                H1(j,i) = H1(i,j);
                            end
                        end
                    end
                    H = H + H1;
                end
            else
                H = zeros(size(C.F,2));
            end
            
            switch lower(ordertype)
                case 'model'
                    switch lower(C.BasisShape)
                        case 'gaussian'
                            
                            for ord = 1:length(order)
                                
                                switch order(ord)
                                    case 0
                                        Func = C.BasisFunc;
                                        
                                    case 1
                                        g_var = (C.w/3)^2;
                                        Func = @(z,src_pos) ((src_pos-z)/sqrt(2*pi*g_var^3) .* exp(-(z-src_pos).^2./(2*g_var))) .* (abs(z-src_pos)<=C.w);
                                    
                                    case 2
                                        g_var = (C.w/3)^2;
                                        Func = @(z,src_pos) (((src_pos-z).^2-g_var)/sqrt(2*pi*g_var^5) .* exp(-(z-src_pos).^2./(2*g_var))) .* (abs(z-src_pos)<=C.w);
                                    
                                end
                                
                                A = zeros(C.NumSrc,C.NumSrc);
                                for i = 1:C.NumSrc
                                    for j = 1:i
                                        
                                        g_int = @(zs) Func(zs, C.Src(i)) .* Func(zs, C.Src(j)) ;
                                        A(i,j) = quadgk(g_int, C.SourceRegionBounds(1)-C.w,C.SourceRegionBounds(2)+C.w);
                                        
                                        if i ~= j
                                            A(j,i) = A(i,j);
                                        end
                                    end
                                end
                                
                                H1 = zeros(C.NumEl);
                                for i = 1:C.NumEl
                                    for j = 1:i
                                        
                                        H1(i,j) = C.bPotMat(:,i)'*A*C.bPotMat(:,j);
                                        if i ~= j
                                            H1(j,i) = H1(i,j);
                                        end
                                    end
                                end
                                
                                
                                H = H+H1;
                                
                            end
                            
                            [H, p] = chol(H);
                            if p ~= 0
                                warning('Cholesky factorization has failed because matrix was found to not be positive-definite');
                            end
                            
                        case 'step'
                            warning('Model Norm Measure is not Possible for Step Basis. Same Procedure as Coeff used!');
                            for ord = 1:length(order)
                                
                                H1 = get_l(size(C.F,2),order(ord));
                                
                                if length(order)>1 || ExtraReg
                                    H = H+H1'*H1;
                                else
                                    H = H1;
                                end
                            end
                            
                            if length(order)>1 || ExtraReg
                                [H, p] = chol(H);
                                if p ~= 0
                                    warning('Cholesky factorization has failed because matrix was found to not be positive-definite');
                                end
                            end
                    end
                    
                case 'coeff'
                    switch lower(C.BasisShape)
                        case 'step'
                            for ord = 1:length(order)
                                
                                H1 = get_l(size(C.F,2),order(ord));
                                
                                if length(order)>1 || ExtraReg
                                    H = H+H1'*H1;
                                else
                                    H = H1;
                                end
                            end
                            
                            if length(order)>1 || ExtraReg
                                [H, p] = chol(H);
                                if p ~= 0
                                    warning('Cholesky factorization has failed because matrix was found to not be positive-definite');
                                end
                            end
                            
                        case 'gaussian'
                            for ord = 1:length(order)
                                
%                                 H1 = get_l(size(C.F,2),order(ord));
                                
                                switch order(ord)
                                    case 0
                                        H1 = full(get_l(size(C.F,2),order(ord)));
                                    case 1
                                        H1 = cat(1, [1 zeros(1,size(C.F,2)-1)], full(get_l(size(C.F,2),order(ord))));
                                    case 2
                                        H1 = cat(1, [-2 1 zeros(1,size(C.F,2)-2)], full(get_l(size(C.F,2),order(ord))),...
                                            [zeros(1,size(C.F,2)-2) 1 -2]);
                                end

                                if length(order)>1 || ExtraReg
                                    H = H+H1'*H1;
                                else
                                    H = H1;
                                end
                            end
                            
                            if length(order)>1 || ExtraReg
                                [H, p] = chol(H);
                                if p ~= 0
                                    warning('Cholesky factorization has failed because matrix was found to not be positive-definite');
                                end
                            end
                    end
            end
            
            
            
        end
        
        function Err2norm = GetWeightMisfitNorm(C, IdealBasisWeights,EstimatedWeights)
            
            misfit = IdealBasisWeights - EstimatedWeights;
            
            Err2norm = sqrt(misfit'*C.NormMeasMat*misfit);
            
        end
        
    end
    
    methods (Access = private)
        
        function MakeSrc(C)
            %% Used Variables:
            % NumSrc: Number of sources
            % SourceRegionBounds: Boundaries of the region where the
            % sources are placed.
            
            %% Output:
            % Src: Center position of each source
            
            %% Computation
            
            C.Src = linspace(C.SourceRegionBounds(1),C.SourceRegionBounds(2),C.NumSrc);
            
        end
        
        function bPotMatrixCalc(C)
            
            %% Used Variables:
            % Src: Center Positions of the sources
            % ElectrodePositions: Positions of the electrodes (boundary assumed to be at z = 0)
            % w: Support of the source (if 'step' the step goes from src-w/2:src+w/2, if
            % 'gauss' the w represents the 3 sigma value of the gaussian, i.e. 99%)
            % R: Radius of the source in the lateral dimension
            % ExCond: Conductity at z > 0
            % TopCond: Conductivity at z < 0
            % SourceShape: Lateral Shape of the source, either 'Uniform' or 'Gaussian'
            % BasisShape: Shape of the basis function, either 'Step' or 'Gaussian'
            
            %% Output:
            % BasisFunc: Handle to the equation describing the CSD basis
            % function (e.g. 'Gaussian' or 'Step')
            % bPotMatrix: Matrix of potential basis elements corresponding to each
            % source (NumSrc, NumEl)
            
            %% Computation
            
            elPos = C.ElectrodePositions;
            R = C.R;
            
            switch lower(C.BasisShape)
                case 'step'
                    C.BasisFunc = @(z,src_pos) ones(size(z));
                    int_bound = 0.5*C.w;
                    
                case 'gaussian'
                    g_var = (C.w/3)^2; % w is the 3 sigma point of the gaussian
                    C.BasisFunc = @(z,src_pos) (1/sqrt(2*pi*g_var) .* exp(-(z-src_pos).^2./(2*g_var))) .* (abs(z-src_pos)<=C.w);
                    int_bound = C.w; %4*C.w % Why does kCSD use 4w?
            end
            
            C.bPotMat = zeros(C.NumSrc, C.NumEl);
            for elInd = 1:C.NumEl
                ze = elPos(elInd);
                
                for srcInd = 1:C.NumSrc
                    currSrc = C.Src(srcInd); % Source Center Position
                    
                    g_int = @(zs) C.BasisFunc(zs,currSrc) .* C.ForwardFunc(zs,ze,R);
                    C.bPotMat(srcInd, elInd) = quadgk(g_int, currSrc-int_bound,currSrc+int_bound);
                end
                
            end
        end
        
        function bSrcMatrixCalc(C)
            %% Used Variables:
            % ReadOutRegion: Region where the CSD should be calculated
            % NumReadOut: length of ReadOutRegion
            % Src: Center position of each source
            % NumSrc: Number of sources
            % BasisFunc: function handle describing the basis as a function
            % of depth
            
            %% Output:
            % bSrcMat: Matrix of basis functions in CSD space
            % (NumReadOut, NumSrc)
            
            %% Computation
            
            C.bSrcMat = nan(C.NumReadOut, C.NumSrc);
            
            for currentSrc = 1:C.NumSrc
                
                C.bSrcMat(:,currentSrc) = C.BasisFunc(C.ReadOutRegion,C.Src(currentSrc));
                
            end
            
        end
        
    end
    
end